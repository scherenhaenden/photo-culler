import React, { useState } from 'react';
import { PhotoItem, CullStatus, FilterOptions } from '../types';
import { Star, Check, X, Tag, SlidersHorizontal, ArrowUpDown, Grid, CheckSquare, Eye } from 'lucide-react';

interface LibraryGridProps {
  photos: PhotoItem[];
  selectedPhotoIds: string[];
  onToggleSelectPhoto: (id: string, isMulti: boolean) => void;
  onOpenCinema: (photo: PhotoItem) => void;
  onUpdateStatusBatch: (ids: string[], status: CullStatus) => void;
  onUpdateRatingBatch: (ids: string[], rating: number) => void;
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
}

export const LibraryGrid: React.FC<LibraryGridProps> = ({
  photos,
  selectedPhotoIds,
  onToggleSelectPhoto,
  onOpenCinema,
  onUpdateStatusBatch,
  onUpdateRatingBatch,
  filters,
  onFilterChange,
}) => {
  const [gridSize, setGridSize] = useState<'sm' | 'md' | 'lg'>('md');

  const handleSelectAll = () => {
    if (selectedPhotoIds.length === photos.length) {
      onToggleSelectPhoto('', false);
    } else {
      photos.forEach((p) => onToggleSelectPhoto(p.id, true));
    }
  };

  const gridColsClass =
    gridSize === 'sm'
      ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6'
      : gridSize === 'md'
      ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'
      : 'grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3';

  return (
    <section className="flex-1 flex flex-col bg-[#050505] select-none font-sans overflow-hidden">
      {/* Grid Controls Toolbar */}
      <div className="h-[46px] bg-[#111111] border-b border-white/10 flex items-center justify-between px-4 shrink-0 text-[11px]">
        <div className="flex items-center gap-4">
          <span className="text-white/40 uppercase font-extrabold tracking-[0.15em] text-[10px]">
            {photos.length} CATALOGUED
          </span>

          {/* Sort Control */}
          <div className="flex items-center gap-1.5 bg-[#050505] px-2.5 py-1 rounded-full border border-white/10 text-white/80">
            <span className="text-white/40 text-[10px] uppercase font-bold tracking-wider">Sort:</span>
            <select
              value={filters.sortBy}
              onChange={(e) =>
                onFilterChange({
                  ...filters,
                  sortBy: e.target.value as FilterOptions['sortBy'],
                })
              }
              className="bg-transparent text-white font-bold focus:outline-none cursor-pointer"
            >
              <option value="captureTime" className="bg-[#111111] text-white">Capture Time</option>
              <option value="sharpness" className="bg-[#111111] text-white">Sharpness Score</option>
              <option value="rating" className="bg-[#111111] text-white">Star Rating</option>
              <option value="filename" className="bg-[#111111] text-white">Filename</option>
            </select>
            <button
              onClick={() =>
                onFilterChange({
                  ...filters,
                  sortOrder: filters.sortOrder === 'asc' ? 'desc' : 'asc',
                })
              }
              className="p-0.5 hover:text-[#FF6B35]"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-[#FF6B35]" />
            </button>
          </div>
        </div>

        {/* Batch Actions & View Controls */}
        <div className="flex items-center gap-3">
          {/* Selected items batch actions */}
          {selectedPhotoIds.length > 0 && (
            <div className="flex items-center gap-1.5 bg-[#111111] px-2.5 py-1 rounded-full border border-[#FF6B35]/50 animate-fadeIn">
              <span className="text-white font-black uppercase tracking-wider text-[10px]">
                {selectedPhotoIds.length} Sel:
              </span>
              <button
                onClick={() => onUpdateStatusBatch(selectedPhotoIds, 'keep')}
                className="px-2 py-0.5 bg-[#25A18E] text-white rounded-full font-extrabold text-[9px] uppercase tracking-wider transition-transform hover:scale-105"
                title="Mark Selected Keep (K)"
              >
                Keep
              </button>
              <button
                onClick={() => onUpdateStatusBatch(selectedPhotoIds, 'alt')}
                className="px-2 py-0.5 bg-[#F7C59F] text-black rounded-full font-extrabold text-[9px] uppercase tracking-wider transition-transform hover:scale-105"
                title="Mark Selected Alt (A)"
              >
                Alt
              </button>
              <button
                onClick={() => onUpdateStatusBatch(selectedPhotoIds, 'reject')}
                className="px-2 py-0.5 bg-[#FF6B35] text-white rounded-full font-extrabold text-[9px] uppercase tracking-wider transition-transform hover:scale-105"
                title="Mark Selected Reject (X)"
              >
                Reject
              </button>
            </div>
          )}

          <button
            onClick={handleSelectAll}
            className="flex items-center gap-1 text-white/70 hover:text-white px-3 py-1 rounded-full border border-white/10 bg-[#050505] font-bold text-[10px] uppercase tracking-wider"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>{selectedPhotoIds.length === photos.length ? 'Deselect All' : 'Select All'}</span>
          </button>

          {/* Grid Size Switcher */}
          <div className="flex items-center gap-0.5 bg-[#050505] p-0.5 rounded-full border border-white/10">
            <button
              onClick={() => setGridSize('sm')}
              className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest ${
                gridSize === 'sm' ? 'bg-[#FF6B35] text-white' : 'text-white/40'
              }`}
            >
              Small
            </button>
            <button
              onClick={() => setGridSize('md')}
              className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest ${
                gridSize === 'md' ? 'bg-[#FF6B35] text-white' : 'text-white/40'
              }`}
            >
              Med
            </button>
            <button
              onClick={() => setGridSize('lg')}
              className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest ${
                gridSize === 'lg' ? 'bg-[#FF6B35] text-white' : 'text-white/40'
              }`}
            >
              Large
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid Viewport */}
      <div className="flex-1 overflow-y-auto p-4 relative">
        {/* Subtle Watermark */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[180px] font-black italic text-white/[0.015] select-none pointer-events-none tracking-tighter uppercase">
          CULL
        </div>

        {photos.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-white/40">
            <SlidersHorizontal className="w-10 h-10 mb-3 text-white/20" />
            <p className="text-[14px] font-bold uppercase tracking-wider">No photos match current filters.</p>
            <p className="text-[11px] text-white/30 mt-1 font-mono">Try resetting search or threshold limits.</p>
          </div>
        ) : (
          <div className={`grid ${gridColsClass} gap-3 relative z-10`}>
            {photos.map((photo) => {
              const isSelected = selectedPhotoIds.includes(photo.id);
              const score = (photo.analysis.sharpness * 10).toFixed(1);

              return (
                <div
                  key={photo.id}
                  onClick={(e) => onToggleSelectPhoto(photo.id, e.shiftKey || e.metaKey || e.ctrlKey)}
                  onDoubleClick={() => onOpenCinema(photo)}
                  className={`relative aspect-[4/3] group cursor-pointer border rounded-2xl overflow-hidden bg-[#111111] transition-all shadow-md ${
                    isSelected
                      ? 'border-[#FF6B35] ring-2 ring-[#FF6B35]'
                      : photo.status === 'keep'
                      ? 'border-[#25A18E]/60 hover:border-[#25A18E]'
                      : photo.status === 'alt'
                      ? 'border-[#F7C59F]/60 hover:border-[#F7C59F]'
                      : photo.status === 'reject'
                      ? 'border-[#FF6B35]/40 opacity-70 hover:opacity-100'
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <img
                    src={photo.thumbnailUrl || photo.url}
                    alt={photo.altText}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Top Left: RAW Badge */}
                  {photo.exif.isRaw && (
                    <div className="absolute top-2 left-2 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/10">
                      <span className="text-[9px] text-white font-extrabold uppercase tracking-widest">RAW</span>
                    </div>
                  )}

                  {/* Top Right: Technical Score Badge */}
                  <div className="absolute top-2 right-2 bg-black/80 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/15">
                    <span className="font-mono text-[10px] text-[#25A18E] font-bold">
                      {score}
                    </span>
                  </div>

                  {/* Bottom Right: Cull Status Indicator */}
                  <div className="absolute bottom-2 right-2 flex gap-1 z-10">
                    {photo.status === 'keep' && (
                      <div className="w-6 h-6 bg-[#25A18E] rounded-full flex items-center justify-center shadow-lg">
                        <Check className="w-4 h-4 text-white stroke-[3]" />
                      </div>
                    )}
                    {photo.status === 'alt' && (
                      <div className="w-6 h-6 bg-[#F7C59F] rounded-full flex items-center justify-center shadow-lg">
                        <Tag className="w-3.5 h-3.5 text-black stroke-[3]" />
                      </div>
                    )}
                    {photo.status === 'reject' && (
                      <div className="w-6 h-6 bg-[#FF6B35] rounded-full flex items-center justify-center shadow-lg">
                        <X className="w-4 h-4 text-white stroke-[3]" />
                      </div>
                    )}
                  </div>

                  {/* Hover Overlay with Metadata & Star Rating */}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/60 to-transparent p-3 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end">
                    <div className="flex justify-between items-center">
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${
                              s <= photo.rating
                                ? 'fill-[#FF6B35] text-[#FF6B35]'
                                : 'text-white/20'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[10px] font-mono text-white/90 truncate max-w-[110px]">
                        {photo.exif.filename}
                      </span>
                    </div>

                    <div className="mt-1.5 flex items-center justify-between text-[10px] text-white/60">
                      <span className="font-mono">{photo.exif.iso} ISO</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenCinema(photo);
                        }}
                        className="text-[#FF6B35] hover:underline font-bold uppercase tracking-wider flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
