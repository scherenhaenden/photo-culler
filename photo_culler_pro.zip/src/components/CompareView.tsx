import React, { useState } from 'react';
import { PhotoItem, CullStatus, CompareCount } from '../types';
import { Check, X, Tag, RefreshCw, Layers, ShieldCheck } from 'lucide-react';

interface CompareViewProps {
  photos: PhotoItem[];
  selectedPhotoIds: string[];
  onUpdateStatus: (id: string, status: CullStatus) => void;
  onOpenCinema: (photo: PhotoItem) => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  photos,
  onUpdateStatus,
}) => {
  const [compareCount, setCompareCount] = useState<CompareCount>(4);
  const [syncZoom, setSyncZoom] = useState(true);

  // Take the first N photos (preferring burst photos if present)
  const displayPhotos = photos.slice(0, compareCount);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050505] select-none font-sans overflow-hidden relative">
      {/* Top Comparison Header Toolbar */}
      <div className="h-[46px] bg-[#111111] border-b border-white/10 flex items-center justify-between px-4 shrink-0 text-[11px]">
        <div className="flex items-center gap-4">
          <span className="text-white/40 font-extrabold uppercase tracking-[0.15em] text-[10px]">
            COMPARE MODE [{compareCount}-UP]
          </span>
          <div className="flex gap-1.5">
            {([2, 3, 4] as const).map((num) => (
              <button
                key={num}
                onClick={() => setCompareCount(num)}
                className={`w-7 h-7 rounded-full text-[10px] font-black flex items-center justify-center transition-all ${
                  compareCount === num
                    ? 'bg-[#FF6B35] text-white shadow-md'
                    : 'bg-[#050505] text-white/60 border border-white/10 hover:bg-white/10 hover:text-white'
                }`}
              >
                {num}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-6 text-white/60">
          <button
            onClick={() => setSyncZoom((prev) => !prev)}
            className={`flex items-center gap-1.5 transition-colors text-[10px] uppercase font-bold tracking-wider ${
              syncZoom ? 'text-[#FF6B35]' : 'text-white/40'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>SYNC ZOOM: {syncZoom ? 'ON' : 'OFF'}</span>
          </button>
          <div className="flex items-center gap-1.5 text-white/40 text-[10px] uppercase font-bold tracking-wider">
            <Layers className="w-3.5 h-3.5" />
            <span>FIT: 100%</span>
          </div>
        </div>
      </div>

      {/* Main Comparison Grid */}
      <div
        className={`flex-1 grid gap-2 p-2 bg-[#000000] overflow-hidden ${
          compareCount === 2
            ? 'grid-cols-2'
            : compareCount === 3
            ? 'grid-cols-3'
            : 'grid-cols-2 md:grid-cols-4'
        }`}
      >
        {displayPhotos.map((photo, idx) => {
          const isWinner = photo.status === 'keep';
          const isAlt = photo.status === 'alt';
          const isReject = photo.status === 'reject';
          const sharpPercent = Math.round(photo.analysis.sharpness * 100);

          return (
            <div
              key={photo.id}
              className={`bg-[#050505] relative flex flex-col group overflow-hidden border rounded-2xl ${
                isWinner
                  ? 'border-[#25A18E]'
                  : isAlt
                  ? 'border-[#F7C59F]'
                  : isReject
                  ? 'border-[#FF6B35]'
                  : 'border-white/10'
              }`}
            >
              {/* Photo Image Canvas Stage */}
              <div className="flex-1 relative cursor-crosshair overflow-hidden">
                <img
                  src={photo.url}
                  alt={photo.title}
                  className={`absolute inset-0 w-full h-full object-cover transition-transform duration-300 ${
                    isReject ? 'grayscale-[0.4]' : ''
                  }`}
                />

                {/* Loupe 1:1 Zoom overlay on hover */}
                <div className="absolute top-3 right-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15 opacity-0 group-hover:opacity-100 transition-opacity text-[9px] font-bold uppercase tracking-widest text-white">
                  1:1 Loupe
                </div>

                {/* Status Border Glow overlay */}
                {isReject && (
                  <div className="absolute inset-0 border-4 border-[#FF6B35]/40 pointer-events-none" />
                )}

                {/* Floating Quick Cull Actions */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0 z-20">
                  <button
                    onClick={() => onUpdateStatus(photo.id, 'keep')}
                    className={`px-3 py-1.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest flex items-center gap-1 shadow-xl transition-all cursor-pointer ${
                      isWinner
                        ? 'bg-[#25A18E] text-white scale-105'
                        : 'bg-[#111111] text-white hover:bg-[#25A18E]/20 hover:text-[#25A18E] border border-white/15'
                    }`}
                  >
                    <Check className="w-3 h-3 stroke-[3]" />
                    <span>WINNER</span>
                  </button>

                  <button
                    onClick={() => onUpdateStatus(photo.id, 'alt')}
                    className={`px-3 py-1.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest flex items-center gap-1 shadow-xl transition-all cursor-pointer ${
                      isAlt
                        ? 'bg-[#F7C59F] text-black scale-105'
                        : 'bg-[#111111] text-white hover:bg-[#F7C59F]/20 hover:text-[#F7C59F] border border-white/15'
                    }`}
                  >
                    <Tag className="w-3 h-3 stroke-[3]" />
                    <span>ALT</span>
                  </button>

                  <button
                    onClick={() => onUpdateStatus(photo.id, 'reject')}
                    className={`px-3 py-1.5 rounded-full text-[9px] font-extrabold uppercase tracking-widest flex items-center gap-1 shadow-xl transition-all cursor-pointer ${
                      isReject
                        ? 'bg-[#FF6B35] text-white scale-105'
                        : 'bg-[#111111] text-white hover:bg-[#FF6B35]/20 hover:text-[#FF6B35] border border-white/15'
                    }`}
                  >
                    <X className="w-3 h-3 stroke-[3]" />
                    <span>REJECT</span>
                  </button>
                </div>
              </div>

              {/* Bottom Specs Strip for Panel */}
              <div className="h-16 bg-[#111111] p-3 border-t border-white/10 text-[10px]">
                <div className="flex justify-between items-center mb-1.5">
                  <span
                    className={`font-mono font-bold truncate max-w-[140px] ${
                      isWinner
                        ? 'text-[#25A18E]'
                        : isAlt
                        ? 'text-[#F7C59F]'
                        : isReject
                        ? 'text-[#FF6B35]'
                        : 'text-white'
                    }`}
                  >
                    #{idx + 1} {photo.exif.filename}
                  </span>
                  <span
                    className={`font-mono font-black ${
                      sharpPercent >= 90
                        ? 'text-[#25A18E]'
                        : sharpPercent >= 75
                        ? 'text-white'
                        : 'text-[#FF6B35]'
                    }`}
                  >
                    SHARP: {sharpPercent}%
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1.5 text-[9px] text-white/50 font-mono">
                  <div className="bg-[#050505] p-1 rounded-md text-center border border-white/5">
                    ISO {photo.exif.iso}
                  </div>
                  <div className="bg-[#050505] p-1 rounded-md text-center border border-white/5">
                    {photo.exif.focalLength}
                  </div>
                  <div className="bg-[#050505] p-1 rounded-md text-center border border-white/5">
                    {photo.exif.aperture}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating HUD Latency Indicator Bottom Right */}
      <div className="absolute bottom-14 right-4 bg-[#111111]/90 backdrop-blur-md border border-white/15 p-3 rounded-2xl shadow-2xl z-40 text-[10px] space-y-2 w-48 font-mono">
        <div className="flex justify-between items-center">
          <span className="text-white/40 font-bold uppercase">RENDER LATENCY</span>
          <span className="text-[#FF6B35] font-bold">12ms</span>
        </div>
        <div className="w-full h-1 bg-[#050505] overflow-hidden rounded-full">
          <div className="h-full bg-[#FF6B35] w-[20%]" />
        </div>
        <div className="flex justify-between items-center pt-1">
          <span className="text-white/40 font-bold uppercase">GPU CACHE</span>
          <span className="text-white font-bold">88%</span>
        </div>
      </div>
    </div>
  );
};
