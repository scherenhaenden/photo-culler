import React, { useState, useRef, useEffect } from 'react';
import { PhotoItem, CullStatus } from '../types';
import { analyzeCanvasImage } from '../utils/imageAnalysis';
import { Check, X, Tag, Star, ZoomIn, ZoomOut, Maximize2, Sparkles, Sliders, Activity, Eye, Focus } from 'lucide-react';

interface CinemaViewerProps {
  photos: PhotoItem[];
  currentPhoto: PhotoItem;
  onSelectPhoto: (photo: PhotoItem) => void;
  onUpdateStatus: (id: string, status: CullStatus) => void;
  onUpdateRating: (id: string, rating: number) => void;
}

export const CinemaViewer: React.FC<CinemaViewerProps> = ({
  photos,
  currentPhoto,
  onSelectPhoto,
  onUpdateStatus,
  onUpdateRating,
}) => {
  const [zoomLevel, setZoomLevel] = useState<'fit' | '100%' | '200%'>('fit');
  const [showHeatMap, setShowHeatMap] = useState(false);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [realMetrics, setRealMetrics] = useState(currentPhoto.analysis);

  const imgRef = useRef<HTMLImageElement>(null);

  // Re-analyze when image changes
  useEffect(() => {
    if (imgRef.current) {
      analyzeCanvasImage(imgRef.current).then((metrics) => {
        setRealMetrics({
          ...currentPhoto.analysis,
          ...metrics,
        });
      });
    }
  }, [currentPhoto]);

  const currentIndex = photos.findIndex((p) => p.id === currentPhoto.id);

  const handlePrev = () => {
    if (currentIndex > 0) {
      onSelectPhoto(photos[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (currentIndex < photos.length - 1) {
      onSelectPhoto(photos[currentIndex + 1]);
    }
  };

  const triggerCalibrate = () => {
    setIsCalibrating(true);
    setTimeout(() => {
      setIsCalibrating(false);
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050505] select-none font-sans overflow-hidden relative">
      <main className="flex-1 flex overflow-hidden">
        {/* Left: Filmstrip Bar */}
        <aside className="w-24 bg-[#050505] border-r border-white/10 flex flex-col overflow-y-auto shrink-0 p-2 space-y-2">
          {photos.map((p, idx) => {
            const isSelected = p.id === currentPhoto.id;
            return (
              <div
                key={p.id}
                onClick={() => onSelectPhoto(p)}
                className={`aspect-square bg-[#111111] cursor-pointer relative overflow-hidden group transition-all rounded-xl ${
                  isSelected
                    ? 'border-2 border-[#FF6B35] ring-2 ring-[#FF6B35]/30'
                    : 'border border-white/10 opacity-60 hover:opacity-100'
                }`}
              >
                <img
                  src={p.thumbnailUrl || p.url}
                  alt={p.title}
                  className="w-full h-full object-cover"
                />

                {/* Status indicator dot */}
                {p.status === 'keep' && (
                  <div className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#25A18E] border border-black" />
                )}
                {p.status === 'alt' && (
                  <div className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#F7C59F] border border-black" />
                )}
                {p.status === 'reject' && (
                  <div className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#FF6B35] border border-black" />
                )}

                <div className="absolute bottom-0 right-0 px-1.5 py-0.5 bg-black/80 font-mono text-[9px] text-white font-bold rounded-tl-md">
                  {String(idx + 1).padStart(2, '0')}
                </div>
              </div>
            );
          })}
        </aside>

        {/* Center: Cinema Image Stage */}
        <section className="flex-1 relative bg-[#000000] flex items-center justify-center p-4 overflow-hidden">
          {/* Main Image Viewport */}
          <div className="relative w-full h-full flex items-center justify-center overflow-auto">
            {showHeatMap && currentPhoto.focusMapUrl ? (
              <img
                src={currentPhoto.focusMapUrl}
                alt="Focus Heat Map"
                className={`max-w-full max-h-full object-contain transition-all shadow-2xl ${
                  zoomLevel === '100%' ? 'scale-150' : zoomLevel === '200%' ? 'scale-200' : 'scale-100'
                }`}
              />
            ) : (
              <img
                ref={imgRef}
                src={currentPhoto.url}
                alt={currentPhoto.title}
                onLoad={() => {
                  if (imgRef.current) {
                    analyzeCanvasImage(imgRef.current).then((m) =>
                      setRealMetrics((prev) => ({ ...prev, ...m }))
                    );
                  }
                }}
                className={`max-w-full max-h-full object-contain transition-transform duration-200 shadow-2xl border border-white/10 rounded-lg ${
                  zoomLevel === '100%' ? 'scale-150' : zoomLevel === '200%' ? 'scale-250 cursor-grab' : 'scale-100'
                }`}
              />
            )}

            {/* Floating Glass HUD Top Left */}
            <div className="absolute top-4 left-4 bg-[#111111]/90 backdrop-blur-md px-3.5 py-2 rounded-full border border-white/15 z-20 flex items-center gap-2.5 shadow-xl">
              <span className="w-2 h-2 rounded-full bg-[#FF6B35] animate-pulse" />
              <span className="font-mono text-[11px] text-white font-bold uppercase">
                {currentPhoto.exif.resolution} • {currentPhoto.exif.bitDepth}
              </span>
            </div>

            {/* Floating Glass HUD Top Right (Zoom & Focus Specs) */}
            <div className="absolute top-4 right-4 bg-[#111111]/90 backdrop-blur-md px-4 py-2 rounded-full border border-white/15 z-20 flex gap-4 text-[11px] shadow-xl">
              <div className="text-right">
                <div className="text-[9px] text-white/40 uppercase font-bold tracking-widest">ZOOM</div>
                <div className="text-white font-black uppercase font-mono">{zoomLevel}</div>
              </div>
              <div className="w-px h-full bg-white/15" />
              <div className="text-right">
                <div className="text-[9px] text-white/40 uppercase font-bold tracking-widest">FOCUS SCORE</div>
                <div className="text-[#25A18E] font-extrabold font-mono">
                  {Math.round((realMetrics.sharpness || 0.94) * 100)}% SHARP
                </div>
              </div>
            </div>

            {/* Center Controls Overlay Bottom Floating Bar */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#111111]/95 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/20 z-30 flex items-center gap-4 shadow-2xl">
              {/* Culling Action Buttons */}
              <button
                onClick={() => onUpdateStatus(currentPhoto.id, 'keep')}
                className={`px-3.5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentPhoto.status === 'keep'
                    ? 'bg-[#25A18E] text-white shadow-lg shadow-[#25A18E]/30 scale-105'
                    : 'bg-white/5 text-white hover:bg-[#25A18E]/20 hover:text-[#25A18E] border border-white/10'
                }`}
              >
                <Check className="w-3.5 h-3.5" />
                <span>KEEP (K)</span>
              </button>

              <button
                onClick={() => onUpdateStatus(currentPhoto.id, 'alt')}
                className={`px-3.5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentPhoto.status === 'alt'
                    ? 'bg-[#F7C59F] text-black shadow-lg shadow-[#F7C59F]/30 scale-105'
                    : 'bg-white/5 text-white hover:bg-[#F7C59F]/20 hover:text-[#F7C59F] border border-white/10'
                }`}
              >
                <Tag className="w-3.5 h-3.5" />
                <span>ALT (A)</span>
              </button>

              <button
                onClick={() => onUpdateStatus(currentPhoto.id, 'reject')}
                className={`px-3.5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentPhoto.status === 'reject'
                    ? 'bg-[#FF6B35] text-white shadow-lg shadow-[#FF6B35]/30 scale-105'
                    : 'bg-white/5 text-white hover:bg-[#FF6B35]/20 hover:text-[#FF6B35] border border-white/10'
                }`}
              >
                <X className="w-3.5 h-3.5" />
                <span>REJECT (X)</span>
              </button>

              <div className="h-4 w-px bg-white/15" />

              {/* Star Rating Buttons */}
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => onUpdateRating(currentPhoto.id, star)}
                    className="p-1 hover:scale-125 transition-transform"
                  >
                    <Star
                      className={`w-3.5 h-3.5 ${
                        star <= currentPhoto.rating
                          ? 'fill-[#FF6B35] text-[#FF6B35]'
                          : 'text-white/20'
                      }`}
                    />
                  </button>
                ))}
              </div>

              <div className="h-4 w-px bg-white/15" />

              {/* Zoom toggle & Focus Map */}
              <div className="flex items-center gap-1.5 text-[10px]">
                <button
                  onClick={() =>
                    setZoomLevel((prev) =>
                      prev === 'fit' ? '100%' : prev === '100%' ? '200%' : 'fit'
                    )
                  }
                  className="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-full text-white font-extrabold uppercase tracking-widest flex items-center gap-1.5 border border-white/10"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-[#FF6B35]" />
                  <span>{zoomLevel.toUpperCase()}</span>
                </button>

                <button
                  onClick={() => setShowHeatMap((prev) => !prev)}
                  className={`px-3 py-1.5 rounded-full font-extrabold uppercase tracking-widest flex items-center gap-1.5 border transition-all ${
                    showHeatMap
                      ? 'bg-[#FF6B35] text-white border-[#FF6B35] shadow-md'
                      : 'bg-white/10 text-white border-white/10 hover:bg-white/20'
                  }`}
                  title="Toggle Focus Edge Heat Map"
                >
                  <Focus className="w-3.5 h-3.5" />
                  <span>Focus Map</span>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Right: Advanced Analysis Panel */}
        <aside className="w-[280px] bg-[#050505] border-l border-white/10 flex flex-col shrink-0 font-sans">
          <div className="h-[46px] flex items-center justify-between px-4 border-b border-white/10 bg-[#111111]">
            <span className="text-[12px] font-black text-white italic tracking-wider uppercase">
              ANALYSIS_ENGINE
            </span>
            <Activity className="w-4 h-4 text-[#FF6B35]" />
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-5 text-[11px]">
            {/* Luma Waveform Graph */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-white/40 uppercase font-bold tracking-widest">
                  Luma Waveform
                </span>
                <span className="text-[#FF6B35] font-mono font-bold">10-BIT</span>
              </div>
              <div className="h-28 w-full bg-[#111111] border border-white/10 rounded-xl relative flex items-end overflow-hidden p-1">
                {/* SVG Luma Waveform */}
                <svg
                  className="w-full h-full opacity-90"
                  preserveAspectRatio="none"
                  viewBox="0 0 200 100"
                >
                  <path
                    d="M0 80 Q 20 20 40 50 T 80 10 T 120 70 T 160 40 T 200 90"
                    fill="none"
                    stroke="#FF6B35"
                    strokeWidth="1.5"
                  />
                  <path
                    d="M0 75 Q 30 40 60 60 T 90 20 T 130 80 T 170 30 T 200 85"
                    fill="none"
                    opacity="0.4"
                    stroke="#25A18E"
                    strokeWidth="1"
                  />
                </svg>
              </div>
            </div>

            {/* RGB Histogram */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-white/40 uppercase font-bold tracking-widest">
                  RGB Histogram
                </span>
                <span className="text-white/40 font-mono">LINEAR</span>
              </div>
              <div className="h-20 w-full bg-[#111111] border border-white/10 rounded-xl relative flex items-end p-1.5 gap-1.5">
                {/* Red Channel */}
                <div className="flex-1 bg-[#FF6B35]/40 h-14 border-t border-[#FF6B35] rounded-t-md" />
                {/* Green Channel */}
                <div className="flex-1 bg-[#25A18E]/40 h-10 border-t border-[#25A18E] rounded-t-md" />
                {/* Blue Channel */}
                <div className="flex-1 bg-[#F7C59F]/40 h-16 border-t border-[#F7C59F] rounded-t-md" />
              </div>
            </div>

            {/* Technical Metrics Specs Grid */}
            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="p-2.5 bg-[#111111] border border-white/10 rounded-xl">
                <div className="text-white/40 font-bold uppercase tracking-wider text-[9px]">SHARPNESS</div>
                <div className="text-white font-mono font-black text-[13px] mt-0.5">
                  {realMetrics.sharpness.toFixed(3)}{' '}
                  <span className="text-[#25A18E]">↑</span>
                </div>
              </div>

              <div className="p-2.5 bg-[#111111] border border-white/10 rounded-xl">
                <div className="text-white/40 font-bold uppercase tracking-wider text-[9px]">MOTION BLUR</div>
                <div className="text-white font-mono font-black text-[13px] mt-0.5">
                  {realMetrics.motionBlurPx} px
                </div>
              </div>

              <div className="p-2.5 bg-[#111111] border border-white/10 rounded-xl">
                <div className="text-white/40 font-bold uppercase tracking-wider text-[9px]">HEADROOM</div>
                <div className="text-white font-mono font-black text-[13px] mt-0.5">
                  +{realMetrics.headroomEv} EV
                </div>
              </div>

              <div className="p-2.5 bg-[#111111] border border-white/10 rounded-xl">
                <div className="text-white/40 font-bold uppercase tracking-wider text-[9px]">NOISE FLOOR</div>
                <div className="text-white font-mono font-black text-[13px] mt-0.5">
                  {realMetrics.noiseFloorDb} dB
                </div>
              </div>
            </div>

            {/* Vectorscope Visualizer */}
            <div className="space-y-2">
              <span className="text-[10px] text-white/40 uppercase font-bold tracking-widest">
                Vectorscope
              </span>
              <div className="aspect-square w-full bg-[#111111] border border-white/10 rounded-full flex items-center justify-center relative overflow-hidden">
                <div className="w-1/2 h-1/2 rounded-full border border-white/20 border-dashed" />
                <div className="w-2.5 h-2.5 bg-[#FF6B35] rounded-full blur-[1px] absolute top-[35%] left-[42%]" />
                <div className="w-3.5 h-3.5 bg-[#25A18E] rounded-full blur-[2px] absolute top-[48%] left-[55%]" />
              </div>
            </div>
          </div>

          {/* Action Button Footer */}
          <div className="p-3 border-t border-white/10 bg-[#050505]">
            <button
              onClick={triggerCalibrate}
              className={`w-full py-2.5 bg-[#111111] border border-white/15 text-white font-bold text-[10px] uppercase tracking-widest rounded-full hover:bg-white/10 transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                isCalibrating ? 'animate-pulse text-[#FF6B35] border-[#FF6B35]' : ''
              }`}
            >
              <Sparkles className="w-4 h-4 text-[#FF6B35]" />
              <span>{isCalibrating ? 'CALIBRATING...' : 'CALIBRATE_COLOR'}</span>
            </button>
          </div>
        </aside>
      </main>

      {/* Bottom Technical Metadata Bar */}
      <footer className="bg-[#000000] border-t border-white/10 flex justify-between items-center px-4 h-8 z-40 text-[10px] text-white/60 shrink-0 select-none">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-white font-mono">
            <span className="text-white/40 font-sans font-bold">CAMERA:</span>
            <span className="font-bold">{currentPhoto.exif.camera}</span>
            <span>•</span>
            <span>{currentPhoto.exif.lens}</span>
          </div>
          <div className="h-3 w-px bg-white/10" />
          <div className="font-mono">
            {currentPhoto.exif.shutterSpeed} • {currentPhoto.exif.aperture} • ISO{' '}
            {currentPhoto.exif.iso}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="font-mono">
            FILE: <span className="text-white font-bold">{currentPhoto.exif.filename}</span>
          </div>
          <div className="h-3 w-px bg-white/10" />
          <div className="flex items-center gap-1.5 text-[#25A18E] font-bold uppercase tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-[#25A18E]" />
            <span>SYSTEM_STATUS_OK</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
