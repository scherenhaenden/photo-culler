import React, { useState } from 'react';
import { PhotoItem } from '../types';
import { analyzeCanvasImage } from '../utils/imageAnalysis';
import { Upload, X, Image as ImageIcon, CheckCircle, Sparkles } from 'lucide-react';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportPhotos: (newPhotos: PhotoItem[]) => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({
  isOpen,
  onClose,
  onImportPhotos,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [importedCount, setImportedCount] = useState(0);

  if (!isOpen) return null;

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(Array.from(e.target.files));
    }
  };

  const processFiles = async (files: File[]) => {
    setIsProcessing(true);
    const newItems: PhotoItem[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!file.type.startsWith('image/')) continue;

      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      img.src = objectUrl;

      await new Promise((res) => {
        img.onload = () => res(true);
        img.onerror = () => res(false);
      });

      const analysis = await analyzeCanvasImage(img);

      const newItem: PhotoItem = {
        id: `custom-photo-${Date.now()}-${i}`,
        title: file.name,
        url: objectUrl,
        altText: `Uploaded photo ${file.name}`,
        exif: {
          camera: 'Local Camera File',
          lens: 'Primary Optical Lens',
          shutterSpeed: '1/500s',
          aperture: 'f/2.8',
          iso: 200,
          focalLength: '50mm',
          ev: '0 EV',
          metering: 'MATRIX',
          afMode: 'AF-C',
          resolution: `${img.naturalWidth || 4000} x ${img.naturalHeight || 3000}`,
          bitDepth: '14-BIT RAW',
          fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
          filename: file.name,
          captureTime: new Date().toISOString().replace('T', ' ').slice(0, 19),
          isRaw: file.name.toUpperCase().endsWith('.RAW') || file.name.toUpperCase().endsWith('.ARW') || file.name.toUpperCase().endsWith('.CR3') || file.name.toUpperCase().endsWith('.NEF') || true,
        },
        analysis,
        status: 'unrated',
        rating: 0,
        sessionName: 'IMPORTED_LOCAL_SESSION',
        tags: ['imported', 'user-upload'],
      };

      newItems.push(newItem);
    }

    setImportedCount(newItems.length);
    setIsProcessing(false);
    onImportPhotos(newItems);
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 font-sans select-none">
      <div className="bg-[#111111] border border-white/10 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="p-4 bg-[#050505] border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 text-[12px] font-black italic uppercase tracking-wider text-white">
            <Upload className="w-4 h-4 text-[#FF6B35]" />
            <span>IMPORT MEDIA ASSETS</span>
          </div>
          <button
            onClick={onClose}
            className="text-white/40 hover:text-white p-1 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dropzone Body */}
        <div className="p-6">
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-white/15 hover:border-[#FF6B35] bg-[#050505] rounded-2xl p-8 flex flex-col items-center justify-center transition-colors cursor-pointer text-center"
          >
            <ImageIcon className="w-12 h-12 text-[#FF6B35] mb-3 animate-pulse" />
            <p className="text-[14px] font-extrabold text-white uppercase italic tracking-wider">
              Drag & Drop Photo Files Here
            </p>
            <p className="text-[10px] text-white/40 font-mono mt-1 uppercase font-bold tracking-widest">
              Supports RAW, ARW, NEF, CR3, JPEG, WebP, PNG files
            </p>

            <label className="mt-5 px-5 py-2.5 bg-[#FF6B35] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 cursor-pointer transition-all flex items-center gap-2 shadow-lg">
              <Sparkles className="w-4 h-4" />
              <span>BROWSE LOCAL FILES</span>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </label>
          </div>

          {/* Status Message */}
          {isProcessing && (
            <div className="mt-4 p-3.5 bg-[#111111] border border-[#FF6B35]/40 rounded-xl text-[10px] font-mono font-bold text-[#FF6B35] uppercase tracking-widest flex items-center gap-2 animate-pulse">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>Analyzing sharpness, Luma waveform & RGB pixel levels...</span>
            </div>
          )}

          {importedCount > 0 && !isProcessing && (
            <div className="mt-4 p-3.5 bg-[#25A18E]/10 border border-[#25A18E]/40 rounded-xl text-[10px] font-mono font-bold text-[#25A18E] uppercase tracking-widest flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>Successfully catalogued {importedCount} new photo(s)!</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050505] border-t border-white/10 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#111111] hover:bg-white/10 border border-white/10 text-white text-[10px] font-black uppercase tracking-widest rounded-full cursor-pointer transition-all"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
