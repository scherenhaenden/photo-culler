import React from 'react';
import { HelpCircle, X, Keyboard } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const hotkeys = [
    { key: '1', label: 'Mark photo as BEST (5 Stars + Keep Tag)' },
    { key: '2 / K', label: 'Mark photo as KEEP (Green Tag)' },
    { key: '3 / A', label: 'Mark photo as ALTERNATE (Cyan Tag)' },
    { key: '4', label: 'Mark photo for REVIEW (3 Stars)' },
    { key: 'X', label: 'Mark photo as REJECTED (Red Tag)' },
    { key: 'R', label: 'Mark photo for RECOVERY' },
    { key: '1 - 5', label: 'Assign Star Rating (1 to 5 Stars)' },
    { key: '0', label: 'Clear Star Rating / Unrate' },
    { key: 'Space', label: 'Toggle Cinema Spec Inspection View' },
    { key: 'C', label: 'Switch to Compare View' },
    { key: '← / →', label: 'Navigate Previous / Next photo' },
    { key: 'Esc', label: 'Clear Selection or Return to Library' },
  ];

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 font-sans select-none">
      <div className="bg-[#111111] border border-white/10 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="p-4 bg-[#050505] border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 text-[12px] font-black italic uppercase tracking-wider text-white">
            <Keyboard className="w-4 h-4 text-[#FF6B35]" />
            <span>KEYBOARD SHORTCUTS CHEATSHEET</span>
          </div>
          <button
            onClick={onClose}
            className="text-white/40 hover:text-white p-1 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Shortcuts List */}
        <div className="p-5 space-y-2 text-[11px]">
          {hotkeys.map((hk, idx) => (
            <div
              key={idx}
              className="flex justify-between items-center p-2.5 bg-[#050505] border border-white/10 rounded-xl"
            >
              <span className="text-white/70 font-mono text-[11px]">{hk.label}</span>
              <kbd className="px-2.5 py-1 bg-[#111111] border border-[#FF6B35]/40 text-[#FF6B35] font-mono font-black rounded-lg text-[10px]">
                {hk.key}
              </kbd>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050505] border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#FF6B35] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 shadow-lg cursor-pointer transition-all"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
