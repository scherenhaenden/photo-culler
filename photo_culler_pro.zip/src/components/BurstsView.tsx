import React, { useState } from 'react';
import { PhotoItem, CullStatus } from '../types';
import { Zap, Check, X, Tag, Star, Award, Sparkles } from 'lucide-react';

interface BurstsViewProps {
  photos: PhotoItem[];
  onUpdateStatus: (id: string, status: CullStatus) => void;
  onOpenCinema: (photo: PhotoItem) => void;
}

export const BurstsView: React.FC<BurstsViewProps> = ({
  photos,
  onUpdateStatus,
  onOpenCinema,
}) => {
  // Group photos by burstId if available, or fall back to session
  const burstGroups: Record<string, PhotoItem[]> = {};
  photos.forEach((p) => {
    const key = p.burstId || p.sessionName;
    if (!burstGroups[key]) burstGroups[key] = [];
    burstGroups[key].push(p);
  });

  const groupKeys = Object.keys(burstGroups);
  const [activeGroupKey, setActiveGroupKey] = useState<string>(
    groupKeys[0] || ''
  );

  const activeBurst = burstGroups[activeGroupKey] || photos;

  // Find the highest sharp score item in active burst
  const winnerCandidate = [...activeBurst].sort(
    (a, b) => b.analysis.sharpness - a.analysis.sharpness
  )[0];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050505] select-none font-sans text-white overflow-hidden">
      {/* Top Burst Selector Bar */}
      <div className="h-[46px] bg-[#111111] border-b border-white/10 flex items-center justify-between px-4 shrink-0 text-[11px]">
        <div className="flex items-center gap-3">
          <Zap className="w-4 h-4 text-[#FF6B35]" />
          <span className="font-black text-white uppercase italic tracking-wider text-[12px]">
            BURST SEQUENCES ({groupKeys.length})
          </span>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex gap-2 overflow-x-auto">
            {groupKeys.map((k) => (
              <button
                key={k}
                onClick={() => setActiveGroupKey(k)}
                className={`px-3 py-1.5 rounded-full text-[10px] font-extrabold uppercase tracking-widest transition-all ${
                  activeGroupKey === k
                    ? 'bg-[#FF6B35] text-white shadow-md'
                    : 'bg-[#050505] text-white/60 border border-white/10 hover:bg-white/10 hover:text-white'
                }`}
              >
                {k} ({burstGroups[k].length} shots)
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Burst Sequence Stage */}
      <div className="flex-1 p-6 overflow-y-auto space-y-6">
        {/* Recommendation Header Banner */}
        {winnerCandidate && (
          <div className="p-4 bg-[#111111] border border-[#25A18E]/50 rounded-2xl flex items-center justify-between shadow-xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-[#25A18E]/10 rounded-full border border-[#25A18E]/30">
                <Award className="w-5 h-5 text-[#25A18E]" />
              </div>
              <div>
                <span className="text-[12px] font-black text-white italic uppercase tracking-wider">
                  AI BEST PICK: {winnerCandidate.exif.filename}
                </span>
                <p className="text-[10px] text-white/40 font-mono mt-0.5 font-bold uppercase tracking-widest">
                  Peak Sharpness Score: {Math.round(winnerCandidate.analysis.sharpness * 100)}% • Eye-AF Target Locked • Open Eyes Vector
                </p>
              </div>
            </div>

            <button
              onClick={() => onUpdateStatus(winnerCandidate.id, 'keep')}
              className="px-4 py-2 bg-[#25A18E] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 transition-all flex items-center gap-2 shadow-lg cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>CONFIRM BEST PICK</span>
            </button>
          </div>
        )}

        {/* Burst Shot Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {activeBurst.map((photo) => {
            const isWinner = winnerCandidate && winnerCandidate.id === photo.id;
            const sharpPercent = Math.round(photo.analysis.sharpness * 100);

            return (
              <div
                key={photo.id}
                onDoubleClick={() => onOpenCinema(photo)}
                className={`bg-[#111111] border rounded-2xl overflow-hidden flex flex-col relative group transition-all ${
                  isWinner
                    ? 'border-[#25A18E] ring-2 ring-[#25A18E]/30'
                    : photo.status === 'keep'
                    ? 'border-[#25A18E]'
                    : photo.status === 'reject'
                    ? 'border-[#FF6B35]'
                    : 'border-white/10'
                }`}
              >
                {/* Image View */}
                <div className="aspect-[4/3] relative bg-[#050505] overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />

                  {/* AI Recommended Badge */}
                  {isWinner && (
                    <div className="absolute top-2.5 left-2.5 bg-[#25A18E] text-white px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1 shadow-lg">
                      <Sparkles className="w-3 h-3 fill-white" />
                      <span>RECOMMENDED</span>
                    </div>
                  )}

                  {/* Sharpness Badge */}
                  <div className="absolute top-2.5 right-2.5 bg-black/80 backdrop-blur-md px-2 py-1 rounded-full font-mono text-[10px] text-[#25A18E] font-extrabold border border-white/10">
                    {sharpPercent}%
                  </div>
                </div>

                {/* Footer Info & Actions */}
                <div className="p-3 bg-[#111111] flex flex-col gap-2.5 text-[10px]">
                  <div className="flex justify-between items-center text-white/60">
                    <span className="font-mono font-bold text-white truncate max-w-[120px]">
                      {photo.exif.filename}
                    </span>
                    <span className="font-mono text-white/40">
                      Frame #{photo.burstIndex || 1}
                    </span>
                  </div>

                  {/* Cull Status Buttons */}
                  <div className="flex gap-1.5 pt-1">
                    <button
                      onClick={() => onUpdateStatus(photo.id, 'keep')}
                      className={`flex-1 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1 transition-all ${
                        photo.status === 'keep'
                          ? 'bg-[#25A18E] text-white'
                          : 'bg-[#050505] text-white/60 border border-white/10 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Check className="w-3 h-3" />
                      <span>Keep</span>
                    </button>

                    <button
                      onClick={() => onUpdateStatus(photo.id, 'alt')}
                      className={`flex-1 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1 transition-all ${
                        photo.status === 'alt'
                          ? 'bg-[#F7C59F] text-black'
                          : 'bg-[#050505] text-white/60 border border-white/10 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Tag className="w-3 h-3" />
                      <span>Alt</span>
                    </button>

                    <button
                      onClick={() => onUpdateStatus(photo.id, 'reject')}
                      className={`flex-1 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-1 transition-all ${
                        photo.status === 'reject'
                          ? 'bg-[#FF6B35] text-white'
                          : 'bg-[#050505] text-white/60 border border-white/10 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <X className="w-3 h-3" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
