import React from 'react';
import { FilterOptions, CullStatus } from '../types';
import { Filter, RotateCcw, Star, Check } from 'lucide-react';

interface FilterSidebarProps {
  filters: FilterOptions;
  onFilterChange: (newFilters: FilterOptions) => void;
  availableCameras: string[];
  totalMatchCount: number;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onFilterChange,
  availableCameras,
  totalMatchCount,
}) => {
  const toggleCamera = (cam: string) => {
    const exists = filters.cameraBody.includes(cam);
    const updated = exists
      ? filters.cameraBody.filter((c) => c !== cam)
      : [...filters.cameraBody, cam];
    onFilterChange({ ...filters, cameraBody: updated });
  };

  const handleReset = () => {
    onFilterChange({
      searchQuery: '',
      cameraBody: [],
      minIso: 100,
      maxIso: 12800,
      minRating: 0,
      cullStatus: 'all',
      rawOnly: false,
      minSharpness: 0,
      sortBy: 'captureTime',
      sortOrder: 'desc',
    });
  };

  return (
    <aside className="w-[230px] bg-[#050505] border-r border-white/10 flex flex-col h-full shrink-0 select-none font-sans">
      {/* Title */}
      <div className="p-3 bg-[#111111] flex justify-between items-center border-b border-white/10">
        <div className="flex items-center gap-2 text-[11px] font-black text-white uppercase italic tracking-wider">
          <Filter className="w-3.5 h-3.5 text-[#FF6B35]" />
          <span>Filters ({totalMatchCount})</span>
        </div>
        <button
          onClick={handleReset}
          className="text-[10px] text-[#FF6B35] hover:text-white uppercase font-bold tracking-widest flex items-center gap-1 cursor-pointer transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-5 text-[11px]">
        {/* Cull Status Filter */}
        <div>
          <h4 className="text-[9px] uppercase text-white/40 mb-2 font-bold tracking-[0.2em]">
            Cull Decision
          </h4>
          <div className="grid grid-cols-2 gap-1.5 text-[10px]">
            {(['all', 'keep', 'alt', 'reject', 'unrated'] as const).map((st) => (
              <button
                key={st}
                onClick={() => onFilterChange({ ...filters, cullStatus: st })}
                className={`px-2 py-1.5 rounded-lg border uppercase font-bold tracking-wider transition-all ${
                  filters.cullStatus === st
                    ? 'bg-[#FF6B35] text-white border-[#FF6B35] shadow-sm'
                    : 'bg-[#111111] text-white/60 border-white/10 hover:bg-white/5 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Camera Body Filter */}
        <div>
          <h4 className="text-[9px] uppercase text-white/40 mb-2 font-bold tracking-[0.2em]">
            Camera Body
          </h4>
          <div className="space-y-1">
            {availableCameras.map((cam) => {
              const isChecked = filters.cameraBody.includes(cam);
              return (
                <label
                  key={cam}
                  onClick={() => toggleCamera(cam)}
                  className="flex items-center justify-between p-1.5 rounded-lg hover:bg-white/5 cursor-pointer text-white/80 transition-colors"
                >
                  <span className="text-[11px] font-medium truncate">{cam}</span>
                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                      isChecked
                        ? 'bg-[#FF6B35] border-[#FF6B35] text-white'
                        : 'border-white/20 bg-[#111111]'
                    }`}
                  >
                    {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                </label>
              );
            })}
          </div>
        </div>

        {/* ISO Range */}
        <div>
          <div className="flex justify-between items-center mb-1">
            <h4 className="text-[9px] uppercase text-white/40 font-bold tracking-[0.2em]">
              ISO Threshold
            </h4>
            <span className="text-[10px] font-mono font-bold text-[#FF6B35]">≤ {filters.maxIso}</span>
          </div>
          <input
            type="range"
            min="100"
            max="12800"
            step="100"
            value={filters.maxIso}
            onChange={(e) =>
              onFilterChange({ ...filters, maxIso: Number(e.target.value) })
            }
            className="w-full accent-[#FF6B35] bg-[#111111] h-1.5 rounded-full cursor-pointer"
          />
          <div className="flex justify-between text-[9px] text-white/40 mt-1 font-mono">
            <span>ISO 100</span>
            <span>ISO 12800+</span>
          </div>
        </div>

        {/* Minimum Sharpness */}
        <div>
          <div className="flex justify-between items-center mb-1">
            <h4 className="text-[9px] uppercase text-white/40 font-bold tracking-[0.2em]">
              Min Sharpness
            </h4>
            <span className="text-[10px] font-mono font-bold text-[#25A18E]">
              {Math.round(filters.minSharpness * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="0.95"
            step="0.05"
            value={filters.minSharpness}
            onChange={(e) =>
              onFilterChange({ ...filters, minSharpness: Number(e.target.value) })
            }
            className="w-full accent-[#25A18E] bg-[#111111] h-1.5 rounded-full cursor-pointer"
          />
        </div>

        {/* Rating Filter */}
        <div>
          <h4 className="text-[9px] uppercase text-white/40 mb-2 font-bold tracking-[0.2em]">
            Min Star Rating
          </h4>
          <div className="flex gap-1">
            {[0, 1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => onFilterChange({ ...filters, minRating: star })}
                className={`flex-1 py-1.5 bg-[#111111] border rounded-lg flex items-center justify-center font-bold text-[10px] transition-colors ${
                  filters.minRating === star
                    ? 'border-[#FF6B35] text-[#FF6B35] bg-[#FF6B35]/10'
                    : 'border-white/10 text-white/40 hover:text-white'
                }`}
              >
                {star === 0 ? 'Any' : star}
              </button>
            ))}
          </div>
        </div>

        {/* RAW Only */}
        <div className="pt-2">
          <label className="flex items-center gap-2 cursor-pointer text-white/80">
            <input
              type="checkbox"
              checked={filters.rawOnly}
              onChange={(e) =>
                onFilterChange({ ...filters, rawOnly: e.target.checked })
              }
              className="accent-[#FF6B35] w-3.5 h-3.5 rounded"
            />
            <span className="text-[11px] font-bold uppercase tracking-wider">RAW Formats Only</span>
          </label>
        </div>
      </div>
    </aside>
  );
};
