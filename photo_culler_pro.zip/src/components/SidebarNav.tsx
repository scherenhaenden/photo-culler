import React from 'react';
import { ViewMode, PhotoItem } from '../types';
import { LayoutGrid, Layers, Calendar, Zap, Activity, Database, HardDrive, CheckCircle2, XCircle, Tag, HelpCircle } from 'lucide-react';

interface SidebarNavProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  photos: PhotoItem[];
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  currentView,
  onViewChange,
  photos,
}) => {
  const keepCount = photos.filter((p) => p.status === 'keep').length;
  const rejectCount = photos.filter((p) => p.status === 'reject').length;
  const altCount = photos.filter((p) => p.status === 'alt').length;
  const unratedCount = photos.filter((p) => p.status === 'unrated').length;

  return (
    <aside className="w-[220px] bg-[#050505] border-r border-white/10 flex flex-col h-full shrink-0 select-none font-sans">
      {/* Master Catalog Header */}
      <div className="p-3 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#111111] border border-white/15 flex items-center justify-center text-[#FF6B35]">
            <Database className="w-4 h-4" />
          </div>
          <div className="overflow-hidden">
            <div className="text-[12px] font-black text-white italic tracking-wider uppercase leading-tight truncate">
              CATALOG_01
            </div>
            <div className="text-[9px] font-bold text-white/40 uppercase tracking-[0.2em]">
              Local Archive
            </div>
          </div>
        </div>
      </div>

      {/* Nav Menu */}
      <nav className="flex-1 py-3 px-2 space-y-1 overflow-y-auto">
        <button
          onClick={() => onViewChange('library')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'library'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <LayoutGrid className="w-4 h-4" />
          <span>Library</span>
        </button>

        <button
          onClick={() => onViewChange('compare')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'compare'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Compare (4-Up)</span>
        </button>

        <button
          onClick={() => onViewChange('bursts')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'bursts'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>Bursts Engine</span>
        </button>

        <button
          onClick={() => onViewChange('timeline')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'timeline'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Timeline</span>
        </button>

        <button
          onClick={() => onViewChange('cinema')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'cinema'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Cinema Specs</span>
        </button>

        <button
          onClick={() => onViewChange('dashboard')}
          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all text-left text-[11px] font-bold uppercase tracking-wider ${
            currentView === 'dashboard'
              ? 'bg-[#FF6B35] text-white shadow-md shadow-[#FF6B35]/20'
              : 'text-white/70 hover:bg-white/5 hover:text-white'
          }`}
        >
          <HardDrive className="w-4 h-4" />
          <span>System Overview</span>
        </button>

        <div className="h-px bg-white/10 my-4 mx-2" />

        {/* Selection Stats */}
        <div className="px-2">
          <div className="text-[9px] font-bold text-white/40 uppercase tracking-[0.2em] mb-2.5">
            Selection Stats
          </div>

          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="flex justify-between items-center bg-[#111111] px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-white/60 flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#25A18E]" />
                KEPT
              </span>
              <span className="font-bold text-[#25A18E]">{keepCount}</span>
            </div>

            <div className="flex justify-between items-center bg-[#111111] px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-white/60 flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider">
                <Tag className="w-3.5 h-3.5 text-[#F7C59F]" />
                ALT (PICK)
              </span>
              <span className="font-bold text-[#F7C59F]">{altCount}</span>
            </div>

            <div className="flex justify-between items-center bg-[#111111] px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-white/60 flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider">
                <XCircle className="w-3.5 h-3.5 text-[#FF6B35]" />
                REJECTED
              </span>
              <span className="font-bold text-[#FF6B35]">{rejectCount}</span>
            </div>

            <div className="flex justify-between items-center bg-[#111111] px-2.5 py-1.5 rounded-lg border border-white/10">
              <span className="text-white/60 flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-wider">
                <HelpCircle className="w-3.5 h-3.5 text-white/40" />
                UNRATED
              </span>
              <span className="font-bold text-white/60">{unratedCount}</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Operator Status Footer */}
      <div className="p-3 border-t border-white/10 bg-[#000000] flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-full border border-white/20 bg-[#111111] overflow-hidden shrink-0">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBEjW7poky3d5DrT4DiQmxA1Y3TjkyItNwN7cYHNHUIT8Z5mLoZIHyvmgQMWgm-oE9Gt7Z3Tn_iQU_0-rnYHTt4IHIPteHUUYwBKlFGefISZkBFQr4N8aHV2-BtfY7WmlGmiljRfE6bRB-lI5ELU-purBuOtl4emr3rAe79bN4OnDtx7J_M3Kv-LDtvrRDqE7ZeQn8l121oj26CUJEEC4uNo3Z8m-Wock9qgU9Hn92nrB4UcZNOJSa0"
            alt="Camera Lens Operator"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="overflow-hidden">
          <div className="text-[11px] font-extrabold text-white uppercase italic tracking-wider truncate">
            OPERATOR_01
          </div>
          <div className="text-[9px] text-[#25A18E] font-bold uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#25A18E] animate-pulse" />
            ACTIVE SESSION
          </div>
        </div>
      </div>
    </aside>
  );
};
