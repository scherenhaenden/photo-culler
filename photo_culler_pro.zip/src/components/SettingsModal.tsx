import React, { useState } from 'react';
import { Settings, X, Cpu, Zap, HardDrive, Check } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [gpuAcceleration, setGpuAcceleration] = useState(true);
  const [workerThreads, setWorkerThreads] = useState(8);
  const [cacheSizeMb, setCacheSizeMb] = useState(4096);
  const [sharpnessThreshold, setSharpnessThreshold] = useState(85);
  const [saved, setSaved] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 font-sans select-none">
      <div className="bg-[#111111] border border-white/10 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="p-4 bg-[#050505] border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 text-[12px] font-black italic uppercase tracking-wider text-white">
            <Settings className="w-4 h-4 text-[#FF6B35]" />
            <span>ENGINE & PERFORMANCE SETTINGS</span>
          </div>
          <button
            onClick={onClose}
            className="text-white/40 hover:text-white p-1 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 text-[11px]">
          {/* GPU Acceleration */}
          <div className="flex items-center justify-between p-3 bg-[#050505] border border-white/10 rounded-xl">
            <div className="flex items-center gap-2.5">
              <Zap className="w-4 h-4 text-[#FF6B35]" />
              <div>
                <div className="font-extrabold text-white uppercase italic tracking-wider text-[11px]">GPU Hardware Acceleration</div>
                <div className="text-[9px] text-white/40 font-mono mt-0.5">
                  Accelerates Luma waveform & Laplacian focus calculation
                </div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={gpuAcceleration}
              onChange={(e) => setGpuAcceleration(e.target.checked)}
              className="accent-[#FF6B35] w-4 h-4 rounded cursor-pointer"
            />
          </div>

          {/* Worker Threads */}
          <div className="p-3 bg-[#050505] border border-white/10 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-extrabold text-white uppercase italic tracking-wider text-[11px] flex items-center gap-2">
                <Cpu className="w-3.5 h-3.5 text-[#FF6B35]" />
                Parallel Processing Threads
              </span>
              <span className="text-[#FF6B35] font-mono font-bold">{workerThreads} Threads</span>
            </div>
            <input
              type="range"
              min="2"
              max="16"
              step="2"
              value={workerThreads}
              onChange={(e) => setWorkerThreads(Number(e.target.value))}
              className="w-full accent-[#FF6B35]"
            />
          </div>

          {/* Cache Allocation */}
          <div className="p-3 bg-[#050505] border border-white/10 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-extrabold text-white uppercase italic tracking-wider text-[11px] flex items-center gap-2">
                <HardDrive className="w-3.5 h-3.5 text-[#FF6B35]" />
                RAM Preview Cache limit
              </span>
              <span className="text-[#FF6B35] font-mono font-bold">{cacheSizeMb} MB</span>
            </div>
            <input
              type="range"
              min="1024"
              max="16384"
              step="1024"
              value={cacheSizeMb}
              onChange={(e) => setCacheSizeMb(Number(e.target.value))}
              className="w-full accent-[#FF6B35]"
            />
          </div>

          {/* AI Auto-Cull Sharpness Threshold */}
          <div className="p-3 bg-[#050505] border border-white/10 rounded-xl space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-extrabold text-white uppercase italic tracking-wider text-[11px]">
                AI Auto-Cull Sharpness Threshold
              </span>
              <span className="text-[#FF6B35] font-mono font-bold">{sharpnessThreshold}%</span>
            </div>
            <input
              type="range"
              min="50"
              max="98"
              step="1"
              value={sharpnessThreshold}
              onChange={(e) => setSharpnessThreshold(Number(e.target.value))}
              className="w-full accent-[#FF6B35]"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050505] border-t border-white/10 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#111111] hover:bg-white/10 border border-white/10 text-white text-[10px] font-black uppercase tracking-widest rounded-full cursor-pointer transition-all"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 bg-[#FF6B35] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 shadow-lg cursor-pointer transition-all flex items-center gap-1.5"
          >
            {saved ? <Check className="w-4 h-4 stroke-[3]" /> : null}
            <span>{saved ? 'Saved!' : 'Save Calibration'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
