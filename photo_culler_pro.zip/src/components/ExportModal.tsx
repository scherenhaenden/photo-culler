import React, { useState } from 'react';
import { PhotoItem } from '../types';
import { Download, X, Trash2, Check, FileText } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  photos: PhotoItem[];
  onPurgeRejected: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  photos,
  onPurgeRejected,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const keepPhotos = photos.filter((p) => p.status === 'keep');
  const altPhotos = photos.filter((p) => p.status === 'alt');
  const rejectPhotos = photos.filter((p) => p.status === 'reject');

  const exportSummary = `PHOTO_CULLER_PRO EXPORT MANIFEST
==================================
Date: ${new Date().toISOString()}
Total Catalog: ${photos.length}

KEPT PHOTOS (${keepPhotos.length}):
${keepPhotos.map((p) => `- ${p.exif.filename} [Sharpness: ${Math.round(p.analysis.sharpness * 100)}%, Rating: ${p.rating}*]`).join('\n')}

ALTERNATE PICKS (${altPhotos.length}):
${altPhotos.map((p) => `- ${p.exif.filename} [Sharpness: ${Math.round(p.analysis.sharpness * 100)}%]`).join('\n')}

REJECTED PHOTOS (${rejectPhotos.length}):
${rejectPhotos.map((p) => `- ${p.exif.filename}`).join('\n')}
`;

  const handleCopyManifest = () => {
    navigator.clipboard.writeText(exportSummary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 font-sans select-none">
      <div className="bg-[#111111] border border-white/10 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="p-4 bg-[#050505] border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 text-[12px] font-black italic uppercase tracking-wider text-white">
            <Download className="w-4 h-4 text-[#FF6B35]" />
            <span>EXPORT & PURGE MANIFEST</span>
          </div>
          <button
            onClick={onClose}
            className="text-white/40 hover:text-white p-1 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5 text-[11px]">
          {/* Summary counts */}
          <div className="grid grid-cols-3 gap-3 text-center font-bold">
            <div className="p-3 bg-[#050505] border border-[#25A18E]/50 rounded-xl">
              <div className="text-[#25A18E] text-[18px] font-mono font-black">{keepPhotos.length}</div>
              <div className="text-[9px] text-white/40 uppercase tracking-widest font-bold">Kept Picks</div>
            </div>
            <div className="p-3 bg-[#050505] border border-[#F7C59F]/50 rounded-xl">
              <div className="text-[#F7C59F] text-[18px] font-mono font-black">{altPhotos.length}</div>
              <div className="text-[9px] text-white/40 uppercase tracking-widest font-bold">Alt Picks</div>
            </div>
            <div className="p-3 bg-[#050505] border border-[#FF6B35]/50 rounded-xl">
              <div className="text-[#FF6B35] text-[18px] font-mono font-black">{rejectPhotos.length}</div>
              <div className="text-[9px] text-white/40 uppercase tracking-widest font-bold">Rejects</div>
            </div>
          </div>

          {/* Textarea Manifest preview */}
          <div>
            <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest mb-1.5">
              Export Manifest Preview
            </div>
            <textarea
              readOnly
              value={exportSummary}
              className="w-full h-32 bg-[#050505] border border-white/10 text-[10px] font-mono p-3 text-white/80 rounded-xl focus:outline-none resize-none"
            />
          </div>

          {/* Purge Rejected Button */}
          {rejectPhotos.length > 0 && (
            <div className="p-4 bg-[#FF6B35]/10 border border-[#FF6B35]/30 rounded-xl flex justify-between items-center">
              <div>
                <div className="font-bold text-[#FF6B35] uppercase tracking-wider text-[11px]">Purge Rejected Assets</div>
                <div className="text-[9px] text-white/40 font-mono mt-0.5">
                  Permanently remove {rejectPhotos.length} rejected file(s) from catalog.
                </div>
              </div>
              <button
                onClick={onPurgeRejected}
                className="px-4 py-2 bg-[#FF6B35] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 transition-all flex items-center gap-1.5 shadow-lg cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>PURGE NOW</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#050505] border-t border-white/10 flex justify-between items-center">
          <button
            onClick={handleCopyManifest}
            className="px-4 py-2 bg-[#111111] hover:bg-white/10 border border-white/15 text-white text-[10px] font-extrabold uppercase tracking-widest rounded-full flex items-center gap-2 transition-all cursor-pointer"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-[#25A18E]" />
            ) : (
              <FileText className="w-3.5 h-3.5 text-[#FF6B35]" />
            )}
            <span>{copied ? 'Copied Manifest!' : 'Copy Text Manifest'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#FF6B35] text-white font-black text-[10px] uppercase tracking-widest rounded-full hover:opacity-90 shadow-lg cursor-pointer transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
