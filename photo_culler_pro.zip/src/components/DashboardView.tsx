import React from 'react';
import { BackgroundJob, VolumeHealth } from '../types';
import { HardDrive, Activity, Zap, ShieldAlert, PlusCircle, RefreshCw, Cpu, Layers, Database } from 'lucide-react';

interface DashboardViewProps {
  jobs: BackgroundJob[];
  volumes: VolumeHealth[];
  onOpenImport: () => void;
  onOpenExport: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  jobs,
  volumes,
  onOpenImport,
}) => {
  return (
    <div className="flex-1 overflow-y-auto p-6 bg-[#050505] select-none font-sans text-white">
      {/* Header Info */}
      <div className="flex justify-between items-end mb-6 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-[20px] font-black uppercase italic tracking-wider text-white">
            System Overview
          </h1>
          <p className="text-[10px] text-white/40 font-mono mt-1 uppercase font-bold tracking-widest">
            OPERATIONAL STATUS: NOMINAL | LAST SYNC: 14:02:11
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={onOpenImport}
            className="bg-[#111111] hover:bg-white/10 border border-white/15 text-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-full flex items-center gap-2 transition-all shadow-md cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 text-[#FF6B35]" />
            <span>NEW IMPORT</span>
          </button>
          <button className="bg-[#111111] hover:bg-white/10 border border-white/15 text-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-full flex items-center gap-2 transition-all shadow-md cursor-pointer">
            <RefreshCw className="w-3.5 h-3.5 text-white/40" />
            <span>SYNC CATALOG</span>
          </button>
        </div>
      </div>

      {/* High Density Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {/* Total Media */}
        <div className="bg-[#111111] p-5 border border-white/10 rounded-2xl">
          <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest">
            Total Media
          </div>
          <div className="text-[28px] text-white font-black tracking-tight mt-1 font-mono">
            142,892
          </div>
          <div className="text-[10px] text-white/40 font-mono flex justify-between mt-3 pt-2 border-t border-white/10">
            <span>RAW: 128,401</span>
            <span>JPEG: 14,491</span>
          </div>
        </div>

        {/* Sessions */}
        <div className="bg-[#111111] p-5 border border-white/10 rounded-2xl">
          <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest">
            Sessions
          </div>
          <div className="text-[28px] text-white font-black tracking-tight mt-1 font-mono">
            412
          </div>
          <div className="mt-3 w-full bg-[#050505] h-1.5 rounded-full overflow-hidden">
            <div className="bg-[#FF6B35] h-full w-[75%]" />
          </div>
          <div className="text-[9px] text-[#FF6B35] mt-1.5 font-extrabold uppercase tracking-widest font-mono">
            75% CATALOGUED
          </div>
        </div>

        {/* AI Best Selects */}
        <div className="bg-[#111111] p-5 border border-white/10 rounded-2xl">
          <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest">
            AI Best Selects
          </div>
          <div className="text-[28px] text-[#25A18E] font-black tracking-tight mt-1 font-mono">
            8,102
          </div>
          <div className="text-[10px] text-[#25A18E] mt-3 flex items-center gap-1 font-extrabold uppercase tracking-widest">
            <Zap className="w-3.5 h-3.5" />
            <span>+12% THIS MONTH</span>
          </div>
        </div>

        {/* Rejected / Trash */}
        <div className="bg-[#111111] p-5 border border-white/10 rounded-2xl">
          <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest">
            Rejected / Trash
          </div>
          <div className="text-[28px] text-[#FF6B35] font-black tracking-tight mt-1 font-mono">
            12,440
          </div>
          <div className="text-[10px] text-white/40 mt-3 font-mono font-bold">
            PENDING PURGE: 42.1GB
          </div>
        </div>
      </div>

      {/* Main Dashboard Bento Grid */}
      <div className="grid grid-cols-12 gap-6">
        {/* Left Column (Growth & Storage) */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          {/* Growth Chart */}
          <div className="bg-[#111111] border border-white/10 p-5 rounded-2xl relative">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-[12px] font-black text-white italic uppercase tracking-wider">
                  Library Growth Distribution
                </h3>
                <div className="flex gap-4 mt-1 text-[10px] text-white/40 uppercase font-bold tracking-widest">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-[#FF6B35] rounded-full" /> RAW ASSETS
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-[#25A18E] rounded-full" /> VIRTUAL COPIES
                  </span>
                </div>
              </div>
            </div>

            {/* Simulated Bar Chart */}
            <div className="h-44 w-full flex items-end gap-2.5 pt-4">
              {[25, 45, 30, 65, 80, 70, 50, 95, 60, 85, 90, 100].map((val, i) => (
                <div key={i} className="flex-1 flex flex-col justify-end h-full gap-1">
                  <div
                    style={{ height: `${val * 0.7}%` }}
                    className="bg-[#FF6B35] hover:opacity-80 rounded-t-md transition-all"
                  />
                  <div
                    style={{ height: `${val * 0.3}%` }}
                    className="bg-[#25A18E]/50 rounded-b-md"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Storage & AI Neural Progress */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Storage Health */}
            <div className="bg-[#111111] border border-white/10 p-5 rounded-2xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[12px] font-black text-white italic uppercase tracking-wider">
                  Volume Health
                </span>
                <HardDrive className="w-4 h-4 text-[#FF6B35]" />
              </div>

              <div className="space-y-3.5 text-[10px] font-mono">
                {volumes.map((vol) => (
                  <div key={vol.id}>
                    <div className="flex justify-between mb-1.5">
                      <span className={vol.isOnline ? 'text-white font-bold' : 'text-white/40'}>
                        {vol.name}
                      </span>
                      <span className="text-white/40">
                        {vol.isOnline ? `${vol.usedPercent}%` : 'DISCONNECTED'}
                      </span>
                    </div>
                    <div className="w-full bg-[#050505] h-1.5 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${vol.usedPercent}%` }}
                        className={`h-full ${
                          vol.usedPercent > 80 ? 'bg-[#FF6B35]' : 'bg-[#25A18E]'
                        }`}
                      />
                    </div>
                  </div>
                ))}

                <div className="flex items-center gap-2 p-2.5 bg-[#FF6B35]/10 border border-[#FF6B35]/20 rounded-xl text-[#FF6B35] text-[9px] font-bold mt-2">
                  <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                  <span>2 Volumes Disconnected: [BACKUP_A, CLOUD_B]</span>
                </div>
              </div>
            </div>

            {/* Neural Processing Gauge */}
            <div className="bg-[#111111] border border-white/10 p-5 rounded-2xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[12px] font-black text-white italic uppercase tracking-wider">
                  Neural AI Processing
                </span>
                <Cpu className="w-4 h-4 text-[#25A18E]" />
              </div>

              <div className="flex items-center gap-4 pt-2">
                <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                  <svg className="w-full h-full -rotate-90">
                    <circle
                      cx="32"
                      cy="32"
                      r="26"
                      stroke="#050505"
                      strokeWidth="4"
                      fill="transparent"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r="26"
                      stroke="#25A18E"
                      strokeWidth="4"
                      strokeDasharray="163"
                      strokeDashoffset="48"
                      fill="transparent"
                    />
                  </svg>
                  <span className="absolute font-mono font-black text-[12px] text-white">
                    70%
                  </span>
                </div>

                <div className="space-y-1 text-[10px] font-mono">
                  <div className="text-white font-bold">SCANNING: Session_2409</div>
                  <div className="text-white/40">ESTIMATED: 12m 40s</div>
                  <div className="flex gap-1 pt-1">
                    <div className="w-1.5 h-3 bg-[#25A18E] rounded-full" />
                    <div className="w-1.5 h-3 bg-[#25A18E] rounded-full" />
                    <div className="w-1.5 h-3 bg-[#25A18E] rounded-full" />
                    <div className="w-1.5 h-3 bg-white/10 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (Pipeline Jobs) */}
        <div className="col-span-12 lg:col-span-4 space-y-4">
          <div className="bg-[#111111] border border-white/10 rounded-2xl flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-white/10 flex justify-between items-center">
              <h4 className="text-[12px] font-black uppercase italic text-white tracking-wider">
                Background Pipeline
              </h4>
              <span className="bg-[#FF6B35] text-white px-2.5 py-0.5 text-[9px] font-black uppercase tracking-widest rounded-full">
                03 ACTIVE
              </span>
            </div>

            <div className="p-3 space-y-2.5">
              {jobs.map((job) => (
                <div
                  key={job.id}
                  className="p-3 bg-[#050505] border border-white/10 rounded-xl hover:border-[#FF6B35] transition-colors"
                >
                  <div className="flex justify-between items-start mb-1 text-[10px] font-mono">
                    <span className="font-bold text-[#FF6B35]">{job.name}</span>
                    <span className="text-white/40">{job.time}</span>
                  </div>
                  <div className="text-[10px] text-white/70 leading-relaxed font-sans">
                    {job.description}
                  </div>
                  <div className="mt-2.5 w-full bg-[#111111] h-1.5 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${job.progress}%` }}
                      className="bg-[#25A18E] h-full"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
