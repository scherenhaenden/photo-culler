import React from 'react';
import { ViewMode } from '../types';
import { Search, Cpu, Zap, Settings, HelpCircle, Upload, Download } from 'lucide-react';

interface TopHeaderProps {
  currentView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenImport: () => void;
  onOpenExport: () => void;
  onOpenSettings: () => void;
  onOpenShortcuts: () => void;
  totalPhotosCount: number;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentView,
  onViewChange,
  searchQuery,
  onSearchChange,
  onOpenImport,
  onOpenExport,
  onOpenSettings,
  onOpenShortcuts,
}) => {
  return (
    <header className="bg-[#050505] border-b border-white/10 flex justify-between items-center h-[46px] px-4 w-full z-50 shrink-0 font-sans select-none">
      {/* Brand & Main View Nav */}
      <div className="flex items-center gap-6">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => onViewChange('dashboard')}
        >
          <span className="font-black text-[16px] tracking-tighter text-white uppercase italic">
            CULLER <span className="text-[#FF6B35] font-normal not-italic">/ 01</span>
          </span>
        </div>

        <div className="h-4 w-px bg-white/10" />

        {/* View Navigation Tabs */}
        <nav className="flex items-center gap-1.5 h-full">
          {(
            [
              { id: 'library', label: 'Library' },
              { id: 'cinema', label: 'Cinema' },
              { id: 'compare', label: 'Compare (4-Up)' },
              { id: 'bursts', label: 'Bursts' },
              { id: 'dashboard', label: 'Dashboard' },
            ] as const
          ).map((tab) => {
            const isActive = currentView === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onViewChange(tab.id)}
                className={`text-[11px] font-bold uppercase tracking-widest px-3 py-1.5 rounded-full transition-all ${
                  isActive
                    ? 'bg-[#FF6B35] text-white shadow-lg shadow-[#FF6B35]/20'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Right Controls & Search */}
      <div className="flex items-center gap-3">
        {/* Search Bar */}
        <div className="relative flex items-center">
          <Search className="w-3.5 h-3.5 absolute left-3 text-white/40 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search filename, lens, tag..."
            className="bg-[#111111] border border-white/15 text-[11px] font-mono text-white/90 placeholder-white/40 rounded-full pl-8 pr-3 py-1 focus:outline-none focus:border-[#FF6B35] w-52 transition-all"
          />
        </div>

        {/* Action Buttons */}
        <button
          onClick={onOpenImport}
          className="bg-white text-black hover:bg-[#F7C59F] text-[10px] font-bold uppercase tracking-widest px-3.5 py-1.5 rounded-full flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
          title="Import photo files"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Import</span>
        </button>

        <button
          onClick={onOpenExport}
          className="bg-[#111111] hover:bg-white/10 border border-white/15 text-white text-[10px] font-bold uppercase tracking-widest px-3.5 py-1.5 rounded-full flex items-center gap-1.5 transition-all cursor-pointer"
          title="Export tagged selection or purge rejects"
        >
          <Download className="w-3.5 h-3.5 text-[#25A18E]" />
          <span>Export</span>
        </button>

        <div className="h-4 w-px bg-white/10 mx-0.5" />

        {/* System & Telemetry Buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenSettings}
            className="p-1.5 hover:bg-white/10 rounded-full text-white/60 hover:text-white transition-colors"
            title="GPU / System Performance"
          >
            <Cpu className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettings}
            className="p-1.5 hover:bg-white/10 rounded-full text-white/60 hover:text-[#FF6B35] transition-colors"
            title="Processing Engine"
          >
            <Zap className="w-4 h-4 text-[#FF6B35]" />
          </button>

          <button
            onClick={onOpenShortcuts}
            className="p-1.5 hover:bg-white/10 rounded-full text-white/60 hover:text-white transition-colors"
            title="Keyboard Shortcuts (K, X, A, 1-5)"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSettings}
            className="p-1.5 hover:bg-white/10 rounded-full text-white/60 hover:text-white transition-colors"
            title="App Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
