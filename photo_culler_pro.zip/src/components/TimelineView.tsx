import React from 'react';
import { PhotoItem } from '../types';
import { Calendar, Camera, Clock, Eye } from 'lucide-react';

interface TimelineViewProps {
  photos: PhotoItem[];
  onOpenCinema: (photo: PhotoItem) => void;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  photos,
  onOpenCinema,
}) => {
  // Group by date string YYYY-MM-DD
  const dateGroups: Record<string, PhotoItem[]> = {};
  photos.forEach((p) => {
    const dateStr = p.exif.captureTime.split(' ')[0] || '2026-07-28';
    if (!dateGroups[dateStr]) dateGroups[dateStr] = [];
    dateGroups[dateStr].push(p);
  });

  const sortedDates = Object.keys(dateGroups).sort().reverse();

  return (
    <div className="flex-1 overflow-y-auto p-6 bg-[#050505] select-none font-sans text-white">
      {/* Timeline Header */}
      <div className="flex items-center gap-3 mb-6 border-b border-white/10 pb-4">
        <Calendar className="w-5 h-5 text-[#FF6B35]" />
        <div>
          <h1 className="text-[18px] font-black uppercase italic tracking-wider text-white">
            Chronological Shoot Timeline
          </h1>
          <p className="text-[10px] text-white/40 font-mono mt-0.5 uppercase font-bold tracking-widest">
            Organized by capture date & session metadata ({photos.length} photos across {sortedDates.length} days)
          </p>
        </div>
      </div>

      {/* Timeline Nodes */}
      <div className="space-y-8">
        {sortedDates.map((date) => {
          const groupPhotos = dateGroups[date];
          return (
            <div key={date} className="relative pl-6 border-l-2 border-white/10">
              {/* Timeline Dot */}
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-[#FF6B35] ring-4 ring-[#050505]" />

              {/* Date Header */}
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-[15px] font-black text-white font-mono">
                    {date}
                  </span>
                  <span className="text-[9px] bg-[#111111] border border-white/10 text-[#25A18E] px-3 py-1 rounded-full font-black uppercase tracking-widest">
                    {groupPhotos.length} Shots
                  </span>
                </div>
                <span className="text-[10px] text-white/40 font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5 text-[#FF6B35]" />
                  {groupPhotos[0]?.exif.camera || 'NIKON Z9'}
                </span>
              </div>

              {/* Photos Grid for this date */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {groupPhotos.map((photo) => (
                  <div
                    key={photo.id}
                    onClick={() => onOpenCinema(photo)}
                    className="aspect-[4/3] bg-[#111111] border border-white/10 hover:border-[#FF6B35] rounded-xl overflow-hidden relative cursor-pointer group transition-all"
                  >
                    <img
                      src={photo.thumbnailUrl || photo.url}
                      alt={photo.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />

                    {/* Time Badge */}
                    <div className="absolute bottom-1.5 right-1.5 bg-black/80 backdrop-blur-sm px-2 py-0.5 rounded-full text-[8px] text-white font-mono flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5 text-[#FF6B35]" />
                      <span>{photo.exif.captureTime.split(' ')[1] || '12:00'}</span>
                    </div>

                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Eye className="w-5 h-5 text-[#FF6B35]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
