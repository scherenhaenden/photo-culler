import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { PhotoItem, CullStatus, ViewMode, FilterOptions } from './types';
import { INITIAL_PHOTOS, INITIAL_JOBS, INITIAL_VOLUMES } from './data/samplePhotos';
import { TopHeader } from './components/TopHeader';
import { SidebarNav } from './components/SidebarNav';
import { FilterSidebar } from './components/FilterSidebar';
import { CinemaViewer } from './components/CinemaViewer';
import { LibraryGrid } from './components/LibraryGrid';
import { CompareView } from './components/CompareView';
import { DashboardView } from './components/DashboardView';
import { BurstsView } from './components/BurstsView';
import { TimelineView } from './components/TimelineView';
import { ImportModal } from './components/ImportModal';
import { ExportModal } from './components/ExportModal';
import { SettingsModal } from './components/SettingsModal';
import { ShortcutsModal } from './components/ShortcutsModal';

export default function App() {
  const [photos, setPhotos] = useState<PhotoItem[]>(INITIAL_PHOTOS);
  const [viewMode, setViewMode] = useState<ViewMode>('library');
  const [selectedPhotoId, setSelectedPhotoId] = useState<string>(
    INITIAL_PHOTOS[0]?.id || ''
  );
  const [selectedPhotoIds, setSelectedPhotoIds] = useState<string[]>([
    INITIAL_PHOTOS[0]?.id || '',
  ]);

  // Modals state
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);

  // Filters state
  const [filters, setFilters] = useState<FilterOptions>({
    searchQuery: '',
    cameraBody: [],
    minIso: 100,
    maxIso: 12800,
    minRating: 0,
    cullStatus: 'all',
    rawOnly: false,
    minSharpness: 0,
    sortBy: 'captureTime',
    sortOrder: 'desc',
  });

  const availableCameras = useMemo(() => {
    const set = new Set<string>();
    photos.forEach((p) => set.add(p.exif.camera));
    return Array.from(set);
  }, [photos]);

  // Currently focused photo object
  const currentPhoto = useMemo(() => {
    return photos.find((p) => p.id === selectedPhotoId) || photos[0];
  }, [photos, selectedPhotoId]);

  // Filter & Sort Logic
  const filteredPhotos = useMemo(() => {
    return photos
      .filter((p) => {
        // Search query
        if (filters.searchQuery) {
          const q = filters.searchQuery.toLowerCase();
          const matchName = p.exif.filename.toLowerCase().includes(q);
          const matchCamera = p.exif.camera.toLowerCase().includes(q);
          const matchLens = p.exif.lens.toLowerCase().includes(q);
          const matchTag = p.tags.some((t) => t.toLowerCase().includes(q));
          const matchSession = p.sessionName.toLowerCase().includes(q);
          if (!matchName && !matchCamera && !matchLens && !matchTag && !matchSession) {
            return false;
          }
        }

        // Camera Body filter
        if (
          filters.cameraBody.length > 0 &&
          !filters.cameraBody.includes(p.exif.camera)
        ) {
          return false;
        }

        // ISO Range
        if (p.exif.iso > filters.maxIso) return false;

        // Rating
        if (p.rating < filters.minRating) return false;

        // Cull Status
        if (filters.cullStatus !== 'all' && p.status !== filters.cullStatus) {
          return false;
        }

        // RAW Only
        if (filters.rawOnly && !p.exif.isRaw) return false;

        // Min Sharpness
        if (p.analysis.sharpness < filters.minSharpness) return false;

        return true;
      })
      .sort((a, b) => {
        let valA: any = a.exif.captureTime;
        let valB: any = b.exif.captureTime;

        if (filters.sortBy === 'sharpness') {
          valA = a.analysis.sharpness;
          valB = b.analysis.sharpness;
        } else if (filters.sortBy === 'rating') {
          valA = a.rating;
          valB = b.rating;
        } else if (filters.sortBy === 'filename') {
          valA = a.exif.filename;
          valB = b.exif.filename;
        }

        if (valA < valB) return filters.sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return filters.sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [photos, filters]);

  // Update Status for single photo or active selections
  const handleUpdateStatus = useCallback((id: string, status: CullStatus) => {
    setPhotos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status } : p))
    );
  }, []);

  const handleUpdateStatusBatch = useCallback((ids: string[], status: CullStatus) => {
    setPhotos((prev) =>
      prev.map((p) => (ids.includes(p.id) ? { ...p, status } : p))
    );
  }, []);

  // Update Rating for single or batch
  const handleUpdateRating = useCallback((id: string, rating: number) => {
    setPhotos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, rating } : p))
    );
  }, []);

  const handleUpdateRatingBatch = useCallback((ids: string[], rating: number) => {
    setPhotos((prev) =>
      prev.map((p) => (ids.includes(p.id) ? { ...p, rating } : p))
    );
  }, []);

  // Toggle selection
  const handleToggleSelectPhoto = useCallback((id: string, isMulti: boolean) => {
    if (!id) {
      setSelectedPhotoIds([]);
      return;
    }
    setSelectedPhotoId(id);

    if (isMulti) {
      setSelectedPhotoIds((prev) =>
        prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
      );
    } else {
      setSelectedPhotoIds([id]);
    }
  }, []);

  const handleOpenCinema = useCallback((photo: PhotoItem) => {
    setSelectedPhotoId(photo.id);
    setSelectedPhotoIds([photo.id]);
    setViewMode('cinema');
  }, []);

  const handleImportPhotos = useCallback((newPhotos: PhotoItem[]) => {
    setPhotos((prev) => [...newPhotos, ...prev]);
    if (newPhotos[0]) {
      setSelectedPhotoId(newPhotos[0].id);
      setSelectedPhotoIds([newPhotos[0].id]);
    }
  }, []);

  const handlePurgeRejected = useCallback(() => {
    setPhotos((prev) => prev.filter((p) => p.status !== 'reject'));
    setIsExportOpen(false);
  }, []);

  // Global Keyboard Shortcuts (K = Keep, X = Reject, A = Alt, 1-5 = Ratings, Space = Cinema)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when typing in inputs or textareas
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT'
      ) {
        return;
      }

      const activeIds = selectedPhotoIds.length > 0 ? selectedPhotoIds : [selectedPhotoId];

      if (e.key === 'k' || e.key === 'K' || e.key === '2') {
        handleUpdateStatusBatch(activeIds, 'keep');
      } else if (e.key === '1') {
        handleUpdateStatusBatch(activeIds, 'keep');
        handleUpdateRatingBatch(activeIds, 5);
      } else if (e.key === '3' || e.key === 'a' || e.key === 'A') {
        handleUpdateStatusBatch(activeIds, 'alt');
      } else if (e.key === '4') {
        handleUpdateStatusBatch(activeIds, 'alt');
        handleUpdateRatingBatch(activeIds, 3);
      } else if (e.key === 'x' || e.key === 'X') {
        handleUpdateStatusBatch(activeIds, 'reject');
      } else if (e.key === 'r' || e.key === 'R') {
        handleUpdateStatusBatch(activeIds, 'keep');
        handleUpdateRatingBatch(activeIds, 4);
      } else if (['5'].includes(e.key)) {
        handleUpdateRatingBatch(activeIds, 5);
      } else if (e.key === '0') {
        handleUpdateRatingBatch(activeIds, 0);
      } else if (e.key === ' ') {
        e.preventDefault();
        setViewMode((prev) => (prev === 'cinema' ? 'library' : 'cinema'));
      } else if (e.key === 'c' || e.key === 'C') {
        setViewMode('compare');
      } else if (e.key === 'ArrowRight') {
        const idx = filteredPhotos.findIndex((p) => p.id === selectedPhotoId);
        if (idx >= 0 && idx < filteredPhotos.length - 1) {
          const next = filteredPhotos[idx + 1];
          setSelectedPhotoId(next.id);
          setSelectedPhotoIds([next.id]);
        }
      } else if (e.key === 'ArrowLeft') {
        const idx = filteredPhotos.findIndex((p) => p.id === selectedPhotoId);
        if (idx > 0) {
          const prev = filteredPhotos[idx - 1];
          setSelectedPhotoId(prev.id);
          setSelectedPhotoIds([prev.id]);
        }
      } else if (e.key === 'Escape') {
        setSelectedPhotoIds([selectedPhotoId]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    selectedPhotoId,
    selectedPhotoIds,
    filteredPhotos,
    handleUpdateStatusBatch,
    handleUpdateRatingBatch,
  ]);

  return (
    <div className="h-screen w-screen bg-[#0F1012] flex flex-col overflow-hidden text-[#e3e2e4]">
      {/* Top Main Navigation Header */}
      <TopHeader
        currentView={viewMode}
        onViewChange={setViewMode}
        searchQuery={filters.searchQuery}
        onSearchChange={(query) => setFilters({ ...filters, searchQuery: query })}
        onOpenImport={() => setIsImportOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        totalPhotosCount={photos.length}
      />

      <div className="flex-1 flex overflow-hidden relative">
        {/* Primary Left Navigation Bar */}
        <SidebarNav
          currentView={viewMode}
          onViewChange={setViewMode}
          photos={photos}
        />

        {/* Filter Drawer for Library View */}
        {viewMode === 'library' && (
          <FilterSidebar
            filters={filters}
            onFilterChange={setFilters}
            availableCameras={availableCameras}
            totalMatchCount={filteredPhotos.length}
          />
        )}

        {/* Active View Render */}
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {viewMode === 'library' && (
            <LibraryGrid
              photos={filteredPhotos}
              selectedPhotoIds={selectedPhotoIds}
              onToggleSelectPhoto={handleToggleSelectPhoto}
              onOpenCinema={handleOpenCinema}
              onUpdateStatusBatch={handleUpdateStatusBatch}
              onUpdateRatingBatch={handleUpdateRatingBatch}
              filters={filters}
              onFilterChange={setFilters}
            />
          )}

          {viewMode === 'cinema' && currentPhoto && (
            <CinemaViewer
              photos={filteredPhotos.length > 0 ? filteredPhotos : photos}
              currentPhoto={currentPhoto}
              onSelectPhoto={(p) => {
                setSelectedPhotoId(p.id);
                setSelectedPhotoIds([p.id]);
              }}
              onUpdateStatus={handleUpdateStatus}
              onUpdateRating={handleUpdateRating}
            />
          )}

          {viewMode === 'compare' && (
            <CompareView
              photos={filteredPhotos.length > 0 ? filteredPhotos : photos}
              selectedPhotoIds={selectedPhotoIds}
              onUpdateStatus={handleUpdateStatus}
              onOpenCinema={handleOpenCinema}
            />
          )}

          {viewMode === 'dashboard' && (
            <DashboardView
              jobs={INITIAL_JOBS}
              volumes={INITIAL_VOLUMES}
              onOpenImport={() => setIsImportOpen(true)}
              onOpenExport={() => setIsExportOpen(true)}
            />
          )}

          {viewMode === 'bursts' && (
            <BurstsView
              photos={photos}
              onUpdateStatus={handleUpdateStatus}
              onOpenCinema={handleOpenCinema}
            />
          )}

          {viewMode === 'timeline' && (
            <TimelineView
              photos={photos}
              onOpenCinema={handleOpenCinema}
            />
          )}
        </div>
      </div>

      {/* Modals */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportPhotos={handleImportPhotos}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        photos={photos}
        onPurgeRejected={handlePurgeRejected}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />
    </div>
  );
}
