export type CullStatus = 'keep' | 'reject' | 'alt' | 'unrated';

export type ViewMode = 'library' | 'cinema' | 'compare' | 'dashboard' | 'bursts' | 'timeline' | 'analysis';

export type CompareCount = 2 | 3 | 4;

export interface ExifData {
  camera: string;
  lens: string;
  shutterSpeed: string;
  aperture: string;
  iso: number;
  focalLength: string;
  ev: string;
  metering: string;
  afMode: string;
  resolution: string;
  bitDepth: string;
  fileSize: string;
  filename: string;
  captureTime: string;
  isRaw: boolean;
}

export interface AnalysisMetrics {
  sharpness: number; // 0.0 - 1.0 or 0 - 100
  motionBlurPx: number;
  headroomEv: number;
  noiseFloorDb: number;
  focusAccuracy: number; // 0 - 10
  compositionScore: number; // 0 - 10
  dynamicRangeScore: number; // 0 - 10
  lumaHistogram?: number[];
  rgbHistogram?: { r: number[]; g: number[]; b: number[] };
}

export interface PhotoItem {
  id: string;
  title: string;
  url: string;
  thumbnailUrl?: string;
  altText: string;
  exif: ExifData;
  analysis: AnalysisMetrics;
  status: CullStatus;
  rating: number; // 0 to 5 stars
  burstId?: string;
  burstIndex?: number;
  burstTotal?: number;
  tags: string[];
  sessionName: string;
  focusMapUrl?: string;
}

export interface FilterOptions {
  searchQuery: string;
  cameraBody: string[];
  minIso: number;
  maxIso: number;
  minRating: number;
  cullStatus: CullStatus | 'all';
  rawOnly: boolean;
  minSharpness: number;
  sortBy: 'captureTime' | 'sharpness' | 'rating' | 'filename';
  sortOrder: 'asc' | 'desc';
}

export interface BackgroundJob {
  id: string;
  name: string;
  description: string;
  time: string;
  progress: number;
  status: 'active' | 'completed' | 'queued';
}

export interface VolumeHealth {
  id: string;
  name: string;
  usedPercent: number;
  totalSize: string;
  isOnline: boolean;
}
