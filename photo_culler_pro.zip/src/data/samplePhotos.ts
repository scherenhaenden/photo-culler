import { PhotoItem, BackgroundJob, VolumeHealth } from '../types';

export const INITIAL_PHOTOS: PhotoItem[] = [
  {
    id: 'photo-01',
    title: 'Dolomites Alpine Sunrise',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuByaqXwSxjogaLYvz0_By-7Jtc6J_eODULayy6ArB2Bp7lLRqvRSmjvrvPFVIaPAZB9ZcJpZx90h4bZNcDla2Z4TC-ZOlZGJ4e7noB5UW_fU6fWwbD4W_sGu0F53XzvJi61wJQNoDS3jDKMEzQk8ikD97lWEDsSjzSBYsf6xkwtM1EjLXdMC4xjL50nxuxl2arbKXutweo9SbJ-6uGbx4tFsk6js_WMc09cIFIheDmQa6Q20YlP3AMC',
    altText: 'A primary high-resolution cinematic landscape of a dramatic mountain range during golden hour. The peaks are illuminated with a deep amber glow.',
    exif: {
      camera: 'NIKON Z9',
      lens: 'NIKKOR Z 50mm f/1.2 S',
      shutterSpeed: '1/250s',
      aperture: 'f/2.8',
      iso: 400,
      focalLength: '50mm',
      ev: '0 EV',
      metering: 'MATRIX',
      afMode: 'AF-C',
      resolution: '8256 x 5504 (45.4 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '54.2 MB',
      filename: 'DSC_8492.NEF',
      captureTime: '2026-07-28 06:14:22',
      isRaw: true
    },
    analysis: {
      sharpness: 0.982,
      motionBlurPx: 2.1,
      headroomEv: 1.4,
      noiseFloorDb: -62.4,
      focusAccuracy: 9.8,
      compositionScore: 9.4,
      dynamicRangeScore: 9.6
    },
    status: 'keep',
    rating: 5,
    sessionName: 'ICELAND_EXPEDITION_RAW',
    tags: ['landscape', 'mountains', 'golden hour', 'raw'],
    focusMapUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAalpp2iJ2rDWzoyV2-e-x8yYuLmNcyiFZzH0Zh5Oj3SQDLvrknhr-L4U4sR2SugwdWGEmH9qjjC6Y4HagzexnNdf9SXpol9Y6cu-Psci53NDjhtYCeSCKhREkYmZKchpfYG7fZZKnkXEctBCPe05gsmrNZG3-o9GoIdH6rsjtJmq9NFYorm8qDYSlN0pZaIOOGbrahxZzHwaPvV65OF0gNLCucDgj0MRzEfcx3szhjHXHbLZjPaYIX'
  },
  {
    id: 'photo-02',
    title: 'Brutalist Concrete Horizon',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAY6qmqwuVoV-m9l8zCkA7FCaLUwvJ6nXuyiNP833jLfk4HOInt2sRJJqWcJpHL4b8zMk8OIOpE4bymGxAionA0X3gp5QwG-_A0nUGJxmqErcAl-Anp4tfqTjE0vFq7m-kuIzJA-8VhhsN38M-9lkxquMq5Xs-8I7Fo5hlEID38Xk67NQlzn74Wn7ArOKWirYyrfbelfIJPQfMBDatpweNFi7qfJlUwdP6mqkRXJK4o0y48iRM_b0vc',
    altText: 'A sharp architectural photograph of a brutalist concrete building with strong shadows and geometric patterns.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 24-70mm f/2.8 GM II',
      shutterSpeed: '1/1000s',
      aperture: 'f/8.0',
      iso: 100,
      focalLength: '35mm',
      ev: '-0.3 EV',
      metering: 'SPOT',
      afMode: 'AF-S',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '68.5 MB',
      filename: 'DSC_4021.ARW',
      captureTime: '2026-07-27 13:45:10',
      isRaw: true
    },
    analysis: {
      sharpness: 0.945,
      motionBlurPx: 0.8,
      headroomEv: 2.1,
      noiseFloorDb: -68.1,
      focusAccuracy: 9.5,
      compositionScore: 9.1,
      dynamicRangeScore: 9.2
    },
    status: 'keep',
    rating: 4,
    sessionName: 'BERLIN_ARCH_STUDY',
    tags: ['architecture', 'monochrome', 'geometry', 'raw']
  },
  {
    id: 'photo-03',
    title: 'Studio Portrait - Frame A (Burst)',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBhBtXCt2oDT8pOSmjvdnxr-xoovSa_z4U3_kDnVoywqChCg9JSPp80Ar6Nsr6_XMJab9WD94NYfPYEUNrS673GfYpCjkWnUQEO2DuGfeiqR9H48CHp2X4DXABLB5tt1Trzw-G8R6i1GP3fUo-WixdBqMY2TMj5Bh5IZc1tgPTuvGmKovJRhpVRAidSY1L9k_8ww9rvXUTkjaPUcNaQCCxY0DV2VusaCRC1Lut9Ns1rXL_yr77SvwSR',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC-aaFiiy0i4NhtaqaW3sR0BQRTGDtoyjeKt2l97vD8mIPdC5Ycn3JpMo-V-2hoM5Lkfzl_hYBUI0pfKjpt5e_8z1IWXB8xvHpBX4NE5apFzbx1ICqu43XUuft7FzaBvbkpOOCGhFZpSIJ4vRGBOuv9iM33yKR4jLWGX0Y5e7fPpfmwU-Jf5Muloo7OZ1Mv6uF7CLtZaQOddPyjvitwG67jf759gm8OrABC6_M4KkGT_ER1vdsweKON',
    altText: 'Professional studio portrait of a woman in sharp focus with dramatic dark lighting and catchlights.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 85mm f/1.4 GM',
      shutterSpeed: '1/320s',
      aperture: 'f/1.4',
      iso: 100,
      focalLength: '85mm',
      ev: '0 EV',
      metering: 'CENTER',
      afMode: 'EYE-AF',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '62.1 MB',
      filename: 'DSC_8492.ARW',
      captureTime: '2026-07-29 15:20:01',
      isRaw: true
    },
    analysis: {
      sharpness: 0.940,
      motionBlurPx: 1.2,
      headroomEv: 1.8,
      noiseFloorDb: -64.0,
      focusAccuracy: 9.4,
      compositionScore: 9.0,
      dynamicRangeScore: 8.9
    },
    status: 'keep',
    rating: 5,
    burstId: 'burst-portrait-01',
    burstIndex: 1,
    burstTotal: 4,
    sessionName: 'STUDIO_PORTRAIT_TEST',
    tags: ['portrait', 'studio', 'headshot', 'burst']
  },
  {
    id: 'photo-04',
    title: 'Studio Portrait - Frame B (Burst Pick)',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDD86QP7T-gH9S5_of6DHjwKqR9dfgZtRH2vA3PRRpJzXfhv0ifM5GmLwoILszLx0xs2FUJotUUKVcKBDxmPzIKNrc5ypDR44vgJw6B13Fj6Vewr00UmBrYlsf730kAyPFYNzqrrZOgSiG9jJPS_m7B7xdM0YbJOmFOhfUVvckce507u2ZGDcgoD2ENycAGjvskAWN_C2d9b6QK8zv-DqOkRs-31rfzx49KpEvR4gcv36AGUlI5rc9h',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDzAhDRVklhTgmG8VLpxE8mDY0Vc4LF9bJp0di78GCRvD2BRTlokOZ4wLs00uYCVyB7lR8x7NlPQnDhQ7lzZcCyhQ8taKgNQ_MbRSo0S1PZz70trKKqhl_1hhzuYRod0vhQM2qRdtk7Mt8qZ0Gnd7MP8fX-YdVnbJSQX3lnqX5qS9Cq9JnPVoeDBYupIC0Gt_YZYQKtUy9Ll4IXvl1RrG8t1lHdJ1Af1WiiEP6drVGTCJGqIdaUw9HW',
    altText: 'Similar professional portrait of the woman with eye focus pin-sharp and catchlight in the eyes.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 85mm f/1.4 GM',
      shutterSpeed: '1/320s',
      aperture: 'f/1.4',
      iso: 100,
      focalLength: '85mm',
      ev: '0 EV',
      metering: 'CENTER',
      afMode: 'EYE-AF',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '62.4 MB',
      filename: 'DSC_8493.ARW',
      captureTime: '2026-07-29 15:20:02',
      isRaw: true
    },
    analysis: {
      sharpness: 0.981,
      motionBlurPx: 0.5,
      headroomEv: 1.9,
      noiseFloorDb: -65.2,
      focusAccuracy: 9.8,
      compositionScore: 9.6,
      dynamicRangeScore: 9.1
    },
    status: 'alt',
    rating: 5,
    burstId: 'burst-portrait-01',
    burstIndex: 2,
    burstTotal: 4,
    sessionName: 'STUDIO_PORTRAIT_TEST',
    tags: ['portrait', 'studio', 'eye-af', 'winner']
  },
  {
    id: 'photo-05',
    title: 'Studio Portrait - Frame C (Slight Blur)',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC7fCmmQJn2HeLAbG5Il84Fz4t7GBaIuyrExVC9E93LI43OttXgaaEzWGpfFBy_D8GWtekV1fm8igFoKc0zwLRqC-4fM5_wW6PoPXQQZzs978nwbcPZYnI4CW2zaUVV5wtiKnk2nAFAH7KR5MAmJf7YBEogQDhxShtVCclZR1V1DQBiyl9WWVGu2nrdp4XQb4q_KUkEmVzEBZ0VC8gPTw241TLKEdCwTjPuafQWvk7asfa8YB0VgKfm',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAoTaKpssIK7qJpU0ARlxSifV7YNugNphwG7u1pcnp-LHxw8CMxhVcmznA6gX_pN-xwmZhCIVCaK4Icbxdk0_RyolinEWiHVUYwqo1tVvxSVWBo6-OJ1FQf_VhmlxMJGcuoj5W66D4nkBZbb5YMrVYfC-E-_ew_OcD2Lj7woQy8Hxp_VsXs_jkJvlTgsayJ3pjOSF706hxtjTsoPksPdC9DniJkptzjUNwhyX0ZVK-2CjIBIcwAItaW',
    altText: 'Portrait series with slightly soft focus on the eyes, illustrating a technical cull scenario.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 85mm f/1.4 GM',
      shutterSpeed: '1/320s',
      aperture: 'f/1.4',
      iso: 100,
      focalLength: '85mm',
      ev: '0 EV',
      metering: 'CENTER',
      afMode: 'EYE-AF',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '61.8 MB',
      filename: 'DSC_8494.ARW',
      captureTime: '2026-07-29 15:20:03',
      isRaw: true
    },
    analysis: {
      sharpness: 0.620,
      motionBlurPx: 4.8,
      headroomEv: 1.5,
      noiseFloorDb: -58.0,
      focusAccuracy: 6.2,
      compositionScore: 8.1,
      dynamicRangeScore: 8.5
    },
    status: 'reject',
    rating: 2,
    burstId: 'burst-portrait-01',
    burstIndex: 3,
    burstTotal: 4,
    sessionName: 'STUDIO_PORTRAIT_TEST',
    tags: ['portrait', 'studio', 'out of focus']
  },
  {
    id: 'photo-06',
    title: 'Studio Portrait - Frame D (Profile View)',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAQ1ILX89p4H7fM_gwrdjwwvU1xjRNdKk-KsRYwMV9Nl30CnU9C8F6BsAbvTVugSsbYuUyIiU1FWFiCTmDrBP3oPBkLCiShxeDXUHW9XQ4ydsoGQm_S0taaMZk-LDPakR5giBYXLzkabb7PeRsh7PoEf2o8D1h8lzfmA4TR8UjV1xpv3srdbx7ouCP2DCqXA8T6oSteZ8aMclz2p4thbw9Y95oMOaRMBjesTRvX4Nb7qmP2T3_oZ1jb',
    thumbnailUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQfIYQuZQCuzim_1RtjJtLAzw4ACFWL8K3brmpf6pizYVsN7vlImxMVh72k-YvgsPFp055GIgAYbeN4lWLj2uW2j1UI3EsD9jKBKal46upV18UvWD4nohEJp37xg-hGUrjmiZxZ4UZc_xuj8RxQ3ATClrl7maf6dgsDbLOP2ycsMUwKd9uYBuUiLAha6rq86VSBYbLXwx1vTMLmQ_OSsjnEH7Sk24Vx6ZRz1KmP4GCsglt64lAhRxd',
    altText: 'Fourth variation in the studio portrait series featuring profile angle and jawline definition.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 85mm f/1.4 GM',
      shutterSpeed: '1/320s',
      aperture: 'f/1.4',
      iso: 100,
      focalLength: '85mm',
      ev: '0 EV',
      metering: 'CENTER',
      afMode: 'EYE-AF',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '62.0 MB',
      filename: 'DSC_8495.ARW',
      captureTime: '2026-07-29 15:20:04',
      isRaw: true
    },
    analysis: {
      sharpness: 0.910,
      motionBlurPx: 1.5,
      headroomEv: 1.7,
      noiseFloorDb: -63.5,
      focusAccuracy: 9.1,
      compositionScore: 8.8,
      dynamicRangeScore: 8.9
    },
    status: 'unrated',
    rating: 4,
    burstId: 'burst-portrait-01',
    burstIndex: 4,
    burstTotal: 4,
    sessionName: 'STUDIO_PORTRAIT_TEST',
    tags: ['portrait', 'profile', 'studio']
  },
  {
    id: 'photo-07',
    title: 'Mechanical Horology Escapement',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_yALpI8gN8JBaVVNzh-ZlpmOeHgawD8Vu1XFskzCu-1CxVp5AVDhkKEVdKdY4f_-0KtphvR86Dxz2Xq7o60FijgyDVelDKjV3owWUHedAKrmN60LCV4tAuyNPbuy5whf67DTvIVRTE7kAWVruLFZwONlZnvHI5yKQ7WYgLdTytV3mCjNtnw9ObNHH0Bhw9TRZCEg43EjOxCXf3XrRJZm2q01xUjELduKuWlkDFm7yZPFaBU_v0IkX',
    altText: 'Macro shot of a complex mechanical watch movement, showing brass gears and steel springs.',
    exif: {
      camera: 'Canon EOS R5',
      lens: 'RF 100mm f/2.8 L MACRO IS USM',
      shutterSpeed: '1/160s',
      aperture: 'f/5.6',
      iso: 200,
      focalLength: '100mm',
      ev: '+0.3 EV',
      metering: 'EVALUATIVE',
      afMode: 'ONE SHOT',
      resolution: '8192 x 5464 (44.8 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '51.9 MB',
      filename: 'IMG_9102.CR3',
      captureTime: '2026-07-25 11:12:00',
      isRaw: true
    },
    analysis: {
      sharpness: 0.968,
      motionBlurPx: 0.6,
      headroomEv: 2.4,
      noiseFloorDb: -70.1,
      focusAccuracy: 9.7,
      compositionScore: 9.3,
      dynamicRangeScore: 9.5
    },
    status: 'keep',
    rating: 5,
    sessionName: 'LUXURY_PRODUCT_CATALOG',
    tags: ['macro', 'horology', 'watch', 'technical']
  },
  {
    id: 'photo-08',
    title: 'Misty Alpine Pine Canopy',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDezFjyizlCm4VVgPhHBL6yPE8265DUB0SoDovL7_De3CwVKs4oxscBS-MCrAHzGu7a0QtUbnun2LuUhxyjpZoz37lV-uFIKv8RYACsHHGhzCrsdZ1QBHzIh95ER1_Bd_eNAvKhVK8p6Fnjozeapla4zQ39goGJlgqUYXuVnq_AZDD_ybMXySwGX-2_keuYM19Ri2pDxdwjqsFgPeyfz8Kw_g11k27p1NsBhYPxOySnS7fE8c2V5-MG',
    altText: 'An expansive aerial view of a misty forest at sunrise with layers of dark green pines fading into fog.',
    exif: {
      camera: 'NIKON Z9',
      lens: 'NIKKOR Z 70-200mm f/2.8 VR S',
      shutterSpeed: '1/500s',
      aperture: 'f/4.0',
      iso: 400,
      focalLength: '135mm',
      ev: '-0.7 EV',
      metering: 'MATRIX',
      afMode: 'AF-C',
      resolution: '8256 x 5504 (45.4 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '56.0 MB',
      filename: 'DSC_9012.NEF',
      captureTime: '2026-07-28 07:02:18',
      isRaw: true
    },
    analysis: {
      sharpness: 0.924,
      motionBlurPx: 1.1,
      headroomEv: 1.6,
      noiseFloorDb: -61.2,
      focusAccuracy: 9.2,
      compositionScore: 9.1,
      dynamicRangeScore: 9.7
    },
    status: 'unrated',
    rating: 4,
    sessionName: 'ICELAND_EXPEDITION_RAW',
    tags: ['landscape', 'aerial', 'forest', 'fog']
  },
  {
    id: 'photo-09',
    title: 'Tokyo Neon Rain Reflections',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB2Sv3OMhVT1NmXcanuU0JE3SpjaDjgEJt2IrWa59dfuYfRZ8_EJ1F8sC4RznBkYKkBhQLk24hGz8-EGX_B5fphtN_F_Nc0pXU5fLhl672_dNLqc-qLH8FhAIx1YG38u0-8iTI9wfd6PAtZ03ya5QTsZi8pnwOzpZYgQZwa_6iNT0qeEtiiidtqJzkwgaI8N0tUwvFtQgzpo-giRSBh3OCxEOUehNtIjYwTiB2ZpNS3z3v5IKjQSQTu',
    altText: 'A street scene at night in a rainy Tokyo neighborhood with vibrant neon signs reflecting in deep puddles.',
    exif: {
      camera: 'Sony A7R IV',
      lens: 'FE 35mm f/1.4 GM',
      shutterSpeed: '1/200s',
      aperture: 'f/1.8',
      iso: 1600,
      focalLength: '35mm',
      ev: '-1.0 EV',
      metering: 'MULTI',
      afMode: 'AF-C',
      resolution: '9504 x 6336 (61.0 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '71.2 MB',
      filename: 'DSC_7781.ARW',
      captureTime: '2026-07-24 22:18:40',
      isRaw: true
    },
    analysis: {
      sharpness: 0.895,
      motionBlurPx: 2.4,
      headroomEv: 2.8,
      noiseFloorDb: -52.4,
      focusAccuracy: 8.9,
      compositionScore: 9.5,
      dynamicRangeScore: 9.8
    },
    status: 'keep',
    rating: 5,
    sessionName: 'TOKYO_NIGHT_SERIES',
    tags: ['street', 'tokyo', 'neon', 'rain', 'night']
  },
  {
    id: 'photo-10',
    title: 'Ethereal Cyan Side-Lit Portrait',
    url: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDPlPWHu150RFbYmxIaY1pbaSnbmLgx8xI9rD_Kw8PX8FVeqfTliWQcDfeBorbXdiFPzEOGkFleIdF9cYex8K-vahtpVTLzT7DE6YIjsg5hhiVSdkaiDVnFKeeuYa2FgZmhZ0gbzrDQLUAwPNkf-ldMXDbzG6X5yokjOsUxxy9WZtMVXs49_2dMd9RnOaHbWuP9d8E0vo2xCxD4Dvr_oEW2lYUUCMiHccqzzOUO-UIYkVekfVeOXD1O',
    altText: 'An ethereal portrait of a person in a dark room illuminated by soft blue side-light with high dynamic range.',
    exif: {
      camera: 'Canon EOS R5',
      lens: 'RF 85mm f/1.2 L USM DS',
      shutterSpeed: '1/250s',
      aperture: 'f/1.2',
      iso: 400,
      focalLength: '85mm',
      ev: '0 EV',
      metering: 'EVALUATIVE',
      afMode: 'EYE-AF',
      resolution: '8192 x 5464 (44.8 MP)',
      bitDepth: '14-BIT RAW',
      fileSize: '53.8 MB',
      filename: 'IMG_4412.CR3',
      captureTime: '2026-07-26 18:30:15',
      isRaw: true
    },
    analysis: {
      sharpness: 0.952,
      motionBlurPx: 0.9,
      headroomEv: 1.3,
      noiseFloorDb: -63.1,
      focusAccuracy: 9.6,
      compositionScore: 9.2,
      dynamicRangeScore: 9.0
    },
    status: 'alt',
    rating: 4,
    sessionName: 'STUDIO_PORTRAIT_TEST',
    tags: ['portrait', 'cyan', 'lighting', 'dramatic']
  }
];

export const INITIAL_JOBS: BackgroundJob[] = [
  {
    id: 'job-01',
    name: 'REINDEXING_DB',
    description: 'Optimizing SQLite metadata tables for Master Catalog.',
    time: '12:10 AM',
    progress: 33,
    status: 'active'
  },
  {
    id: 'job-02',
    name: 'GEN_THUMBNAILS',
    description: 'Processing 4,000 textures for 8K viewport rendering.',
    time: '11:55 PM',
    progress: 68,
    status: 'active'
  },
  {
    id: 'job-03',
    name: 'AI_CULLING_S22',
    description: 'Evaluating sharpness and eye-contact vectors.',
    time: '11:30 PM',
    progress: 92,
    status: 'active'
  }
];

export const INITIAL_VOLUMES: VolumeHealth[] = [
  {
    id: 'vol-1',
    name: 'NVME_PRIMARY',
    usedPercent: 88,
    totalSize: '2.0 TB',
    isOnline: true
  },
  {
    id: 'vol-2',
    name: 'ARCHIVE_VOL_01',
    usedPercent: 42,
    totalSize: '16.0 TB',
    isOnline: true
  },
  {
    id: 'vol-3',
    name: 'BACKUP_A',
    usedPercent: 0,
    totalSize: '8.0 TB',
    isOnline: false
  },
  {
    id: 'vol-4',
    name: 'CLOUD_B',
    usedPercent: 0,
    totalSize: '32.0 TB',
    isOnline: false
  }
];
